import "./globals.css";
import React from "react";
import VoiceAssistant from "@/components/VoiceAssistant";

export const metadata = {
  title: "V-Try | Virtual Try-On Studio",
  description: "AI-powered virtual try-on with Zippi.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-black text-white">
        {children}
        <VoiceAssistant />
      </body>
    </html>
  );
}
