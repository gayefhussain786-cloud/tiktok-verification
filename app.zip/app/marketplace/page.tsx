"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowUpRight, Sparkles } from "lucide-react";

const products = [
  {
    id: "alpha-tight",
    name: "Alpha Compression Tight",
    brand: "V-Try Performance",
    tag: "New Drop",
    price: 79,
    accent: "from-emerald-400/90 via-emerald-300/60 to-emerald-400/30",
  },
  {
    id: "shadow-hoodie",
    name: "Shadow Pump Hoodie",
    brand: "Night Session",
    tag: "Best Seller",
    price: 109,
    accent: "from-zinc-200 via-white/80 to-zinc-500/40",
  },
  {
    id: "phase-tank",
    name: "Phase Pro Tank",
    brand: "Arena Series",
    tag: "Try-On Ready",
    price: 59,
    accent: "from-sky-400 via-cyan-300/80 to-sky-500/40",
  },
  {
    id: "lift-short",
    name: "Lift Session Short",
    brand: "Iron Lab",
    tag: "Limited Run",
    price: 69,
    accent: "from-fuchsia-400 via-pink-300/80 to-fuchsia-500/40",
  },
];

export default function MarketplacePage() {
  return (
    <div className="flex w-full flex-1 flex-col gap-5">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold tracking-tight sm:text-2xl">
            Marketplace
          </h1>
          <p className="mt-1 text-xs text-zinc-400 sm:text-sm">
            Gymshark-inspired drops, all instantly try-on ready with Janvi.
          </p>
        </div>
        <div className="hidden items-center gap-2 rounded-full border border-emerald-400/40 bg-emerald-500/10 px-3 py-1 text-[11px] text-emerald-300 shadow-[0_0_30px_rgba(16,185,129,0.45)] sm:flex">
          <Sparkles className="h-3 w-3" />
          Live virtual try-on
        </div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45 }}
        className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 md:gap-4"
      >
        {products.map((product) => (
          <Link
            key={product.id}
            href={`/marketplace/${product.id}`}
            className="group relative flex flex-col overflow-hidden rounded-3xl border border-white/10 bg-zinc-950/90 p-2 text-xs shadow-[0_0_60px_rgba(0,0,0,0.9)] transition hover:-translate-y-1 hover:border-white/40 hover:shadow-[0_0_90px_rgba(0,0,0,1)]"
          >
            <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-zinc-900/80">
              <div
                className={`pointer-events-none absolute inset-0 bg-gradient-to-br ${product.accent} opacity-80 mix-blend-screen`}
              />
              <div className="relative flex aspect-[4/5] items-center justify-center text-[10px] text-zinc-200">
                <span className="rounded-full bg-black/40 px-2 py-1 text-[9px] uppercase tracking-[0.18em] text-zinc-300">
                  VIRTUAL PREVIEW
                </span>
              </div>
            </div>

            <div className="mt-2 flex flex-1 flex-col gap-1">
              <div className="flex items-center justify-between gap-1">
                <p className="line-clamp-1 text-[11px] font-medium text-zinc-100">
                  {product.name}
                </p>
                <span className="rounded-full bg-white px-2 py-0.5 text-[10px] font-semibold text-black shadow-[0_0_25px_rgba(255,255,255,0.6)]">
                  ${product.price}
                </span>
              </div>
              <p className="text-[10px] uppercase tracking-[0.16em] text-zinc-500">
                {product.brand}
              </p>
              <div className="mt-1 flex items-center justify-between text-[10px] text-zinc-400">
                <span className="rounded-full bg-white/5 px-2 py-0.5 text-[9px] uppercase tracking-[0.16em] text-emerald-300">
                  {product.tag}
                </span>
                <span className="inline-flex items-center gap-1 text-[10px] text-zinc-300">
                  View
                  <ArrowUpRight className="h-3 w-3 transition group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                </span>
              </div>
            </div>
          </Link>
        ))}
      </motion.div>
    </div>
  );
}
