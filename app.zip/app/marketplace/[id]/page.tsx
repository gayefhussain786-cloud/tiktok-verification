"use client";

import { notFound } from "next/navigation";
import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowLeft, ShoppingBag, Ruler, Sparkles } from "lucide-react";

const PRODUCT_DATA = {
  "alpha-tight": {
    name: "Alpha Compression Tight",
    brand: "V-Try Performance",
    price: 79,
    description:
      "Second-skin compression tight engineered for heavy squats, sprints and everything in between.",
  },
  "shadow-hoodie": {
    name: "Shadow Pump Hoodie",
    brand: "Night Session",
    price: 109,
    description:
      "Oversized pump cover with a structured hood and brushed interior for late-night sessions.",
  },
  "phase-tank": {
    name: "Phase Pro Tank",
    brand: "Arena Series",
    price: 59,
    description:
      "Lightweight tank with dropped armholes and sweat-wicking fabric for high-output workouts.",
  },
  "lift-short": {
    name: "Lift Session Short",
    brand: "Iron Lab",
    price: 69,
    description:
      "Split-hem short with four-way stretch and anti-ride construction for deadlifts and leg days.",
  },
} as const;

const sizes = ["XS", "S", "M", "L", "XL"];

export default function ProductPage({
  params,
}: {
  params: { id: string };
}) {
  const product = PRODUCT_DATA[params.id as keyof typeof PRODUCT_DATA];

  if (!product) {
    return notFound();
  }

  return (
    <div className="flex w-full flex-1 flex-col gap-5 md:flex-row md:items-stretch md:gap-8">
      <div className="space-y-3 md:flex-1">
        <Link
          href="/marketplace"
          className="inline-flex items-center gap-1.5 text-xs text-zinc-400 hover:text-zinc-100"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          Back to marketplace
        </Link>

        <div className="mt-1 space-y-2">
          <p className="text-[11px] uppercase tracking-[0.22em] text-zinc-500">
            {product.brand}
          </p>
          <h1 className="text-xl font-semibold tracking-tight sm:text-2xl">
            {product.name}
          </h1>
          <p className="text-xs text-zinc-400 sm:text-sm">
            {product.description}
          </p>
        </div>

        <div className="mt-3 flex items-center gap-2 text-xs text-zinc-300">
          <span className="rounded-full bg-white px-3 py-1 text-sm font-semibold text-black shadow-[0_0_35px_rgba(255,255,255,0.6)]">
            ${product.price}
          </span>
          <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/10 px-3 py-1 text-[11px] text-emerald-300">
            <Sparkles className="h-3 w-3" />
            Try-on compatible
          </span>
        </div>

        {/* Size selector */}
        <div className="mt-4 space-y-1.5 rounded-2xl border border-white/10 bg-zinc-950/80 p-3.5">
          <div className="flex items-center justify-between text-[11px] text-zinc-400">
            <div className="flex items-center gap-1.5">
              <Ruler className="h-3.5 w-3.5" />
              <span>Select size</span>
            </div>
            <span>Size guide</span>
          </div>
          <div className="mt-2 flex flex-wrap gap-1.5">
            {sizes.map((size) => (
              <button
                key={size}
                type="button"
                className="min-w-[2.75rem] rounded-full border border-white/15 bg-zinc-900 px-3 py-1.5 text-xs text-zinc-100 hover:border-white hover:bg-white hover:text-black"
              >
                {size}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-3 flex flex-col gap-2 sm:flex-row">
          <button
            type="button"
            className="inline-flex flex-1 items-center justify-center gap-2 rounded-full bg-white px-4 py-2.5 text-sm font-semibold text-black shadow-[0_0_40px_rgba(255,255,255,0.6)] transition hover:-translate-y-0.5 hover:shadow-[0_0_70px_rgba(255,255,255,0.7)]"
          >
            <ShoppingBag className="h-4 w-4" />
            Add to cart
          </button>
          <Link
            href="/try-on"
            className="inline-flex flex-1 items-center justify-center gap-2 rounded-full border border-white/30 bg-zinc-950 px-4 py-2.5 text-sm font-medium text-zinc-100 transition hover:border-white hover:bg-zinc-900"
          >
            Try this on
          </Link>
        </div>
      </div>

      {/* Visual card */}
      <motion.div
        initial={{ opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45 }}
        className="mt-2 flex flex-1 items-center justify-center md:mt-0"
      >
        <div className="relative w-full max-w-md overflow-hidden rounded-3xl border border-white/10 bg-zinc-950/90 p-3 shadow-[0_0_80px_rgba(0,0,0,0.95)] backdrop-blur-2xl">
          <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-[radial-gradient(circle_at_10%_0%,#27272a,transparent_60%),radial-gradient(circle_at_90%_100%,#111827,transparent_60%)]">
            <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(255,255,255,0.12),transparent_55%),linear-gradient(to_bottom,rgba(15,23,42,0.55),transparent_70%)] mix-blend-screen" />
            <div className="relative flex aspect-[4/5] flex-col items-center justify-center gap-3 px-6 text-center">
              <span className="rounded-full bg-black/50 px-3 py-1 text-[10px] uppercase tracking-[0.2em] text-zinc-300">
                PRODUCT VISUAL
              </span>
              <p className="text-xs text-zinc-300">
                Product hero placeholder. Drop your render or photo here for a
                full Nike-style card.
              </p>
            </div>
          </div>
          <div className="mt-2 flex items-center justify-between text-[11px] text-zinc-400">
            <span>Designed for gym performance</span>
            <span>V-Try Ready</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
}


