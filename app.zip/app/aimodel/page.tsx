"use client";

import { UploadCloud } from "lucide-react";

export default function AIModelGeneratorPage() {
  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      <h1 className="text-4xl font-extrabold">
        AI Model <span className="text-yellow-400">Generator</span>
      </h1>

      <p className="text-gray-400 mt-2 text-sm sm:text-base">
        Upload your clothing and let AI create professional virtual model photos for your products.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-10">
        
        {/* Upload Clothing Box */}
        <div className="bg-neutral-900 border border-white/10 rounded-2xl p-6 min-h-[350px] flex flex-col items-center justify-center text-center">
          <UploadCloud className="w-12 h-12 text-yellow-400 mb-4" />
          <h2 className="text-lg font-bold">Upload Clothing</h2>
          <p className="text-gray-400 text-sm mt-1">
            PNG, JPG up to 10 MB
          </p>
          <button className=" nike-btn mt-4">Upload file</button>
        </div>

        {/* Generated Result Box */}
        <div className="bg-neutral-900 border border-white/10 rounded-2xl p-6 min-h-[350px] flex flex-col items-center justify-center text-center">
          <h2 className="text-lg font-bold">Generated Result</h2>
          <p className="text-gray-400 text-sm mt-1">
            Upload a clothing image to generate your AI model photo.
          </p>
          <div className="mt-4 w-40 h-40 border border-white/10 rounded-xl flex items-center justify-center">
            <span className="text-gray-600 text-sm">No result yet</span>
          </div>
        </div>

      </div>
    </div>
  );
}
