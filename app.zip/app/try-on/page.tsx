"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import {
  Image as ImageIcon,
  SlidersHorizontal,
  User2,
  SquareStack,
  PersonStanding,
} from "lucide-react";
import Link from "next/link";

const skinTones = [
  { id: "tone-1", label: "I", color: "#f6e0c8" },
  { id: "tone-2", label: "II", color: "#e2b899" },
  { id: "tone-3", label: "III", color: "#c58c5c" },
  { id: "tone-4", label: "IV", color: "#8d5524" },
  { id: "tone-5", label: "V", color: "#5a3714" },
];

const backgrounds = ["Studio", "Locker Room", "Stadium", "Street", "Custom"];
const poses = ["Relaxed", "Power", "Run", "Squat", "Side Profile"];

export default function TryOnPage() {
  const [gender, setGender] = useState<"male" | "female" | null>(null);
  const [skinTone, setSkinTone] = useState<string>("tone-3");
  const [background, setBackground] = useState<string>("Studio");
  const [pose, setPose] = useState<string>("Relaxed");

  return (
    <div className="flex flex-1 flex-col gap-5 md:flex-row md:items-stretch md:gap-8">
      {/* Preview card */}
      <motion.div
        initial={{ opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45 }}
        className="flex flex-1 items-center justify-center"
      >
        <div className="relative w-full max-w-md rounded-3xl border border-white/10 bg-zinc-950/90 p-4 shadow-[0_0_80px_rgba(0,0,0,0.95)] backdrop-blur-2xl">
          <div className="mb-2 flex items-center justify-between text-[11px] text-zinc-400">
            <div className="flex items-center gap-1.5">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 shadow-[0_0_10px_rgba(74,222,128,0.9)]" />
              Live preview
            </div>
            <span>
              {gender ? gender === "male" ? "Male" : "Female" : "No gender set"}{" "}
              · {pose}
            </span>
          </div>

          <div className="relative aspect-[9/16] overflow-hidden rounded-2xl border border-white/5 bg-[radial-gradient(circle_at_10%_0%,#27272a,transparent_60%),radial-gradient(circle_at_90%_100%,#111827,transparent_55%)]">
            <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(255,255,255,0.12),transparent_55%),linear-gradient(to_bottom,rgba(15,23,42,0.45),transparent_65%)] mix-blend-screen" />

            <div className="relative flex h-full flex-col items-center justify-center gap-4 px-5 text-center">
              <ImageIcon className="h-10 w-10 text-zinc-500" />
              <p className="text-xs font-medium text-zinc-200">
                Try-on preview placeholder
              </p>
              <p className="text-[11px] text-zinc-400">
                Once your camera and cloth are connected, Janvi will render a
                realistic overlay here.
              </p>
            </div>
          </div>

          <div className="mt-3 flex items-center justify-between rounded-2xl border border-white/10 bg-zinc-900/90 px-3 py-2.5 text-[11px] text-zinc-300">
            <div className="flex items-center gap-1.5">
              <SlidersHorizontal className="h-3.5 w-3.5" />
              <span>Depth-Fit calibration</span>
            </div>
            <span className="rounded-full bg-emerald-500/10 px-2 py-0.5 text-[10px] text-emerald-400">
              Stable
            </span>
          </div>
        </div>
      </motion.div>

      {/* Controls column */}
      <motion.div
        initial={{ opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45, delay: 0.1 }}
        className="flex w-full max-w-md flex-col gap-3 md:max-w-xs"
      >
        <h1 className="text-lg font-semibold tracking-tight sm:text-xl">
          Customize your{" "}
          <span className="bg-gradient-to-r from-zinc-50 via-white to-zinc-400 bg-clip-text text-transparent">
            try-on
          </span>
        </h1>

        <p className="text-xs text-zinc-400">
          Tune Janvi&apos;s preview to match your body, vibe and environment.
        </p>

        <div className="mt-1 space-y-3 rounded-3xl border border-white/10 bg-zinc-950/80 p-3.5 backdrop-blur-2xl">
          {/* Upload cloth shortcut */}
          <div className="flex items-center justify-between rounded-2xl border border-white/10 bg-zinc-900/80 px-3 py-2.5 text-[11px]">
            <div className="flex items-center gap-2 text-zinc-200">
              <ImageIcon className="h-3.5 w-3.5" />
              <span>Active cloth</span>
            </div>
            <Link
              href="/upload"
              className="rounded-full bg-white px-3 py-1 text-[11px] font-semibold text-black shadow-[0_0_25px_rgba(255,255,255,0.4)]"
            >
              Upload cloth
            </Link>
          </div>

          {/* Gender selection */}
          <div className="space-y-1.5">
            <div className="flex items-center gap-1.5 text-[11px] text-zinc-400">
              <User2 className="h-3.5 w-3.5" />
              <span>Select gender</span>
            </div>
            <div className="flex gap-1.5">
              <button
                type="button"
                onClick={() => setGender("male")}
                className={`flex-1 rounded-full px-3 py-1.5 text-xs transition ${
                  gender === "male"
                    ? "bg-white text-black shadow-[0_0_30px_rgba(255,255,255,0.5)]"
                    : "bg-zinc-900 text-zinc-300 hover:bg-zinc-800"
                }`}
              >
                Male
              </button>
              <button
                type="button"
                onClick={() => setGender("female")}
                className={`flex-1 rounded-full px-3 py-1.5 text-xs transition ${
                  gender === "female"
                    ? "bg-white text-black shadow-[0_0_30px_rgba(255,255,255,0.5)]"
                    : "bg-zinc-900 text-zinc-300 hover:bg-zinc-800"
                }`}
              >
                Female
              </button>
            </div>
          </div>

          {/* Skin tone presets */}
          <div className="space-y-1.5">
            <div className="flex items-center gap-1.5 text-[11px] text-zinc-400">
              <SquareStack className="h-3.5 w-3.5" />
              <span>Select skin tone</span>
            </div>
            <div className="flex gap-1.5">
              {skinTones.map((tone) => (
                <button
                  key={tone.id}
                  type="button"
                  onClick={() => setSkinTone(tone.id)}
                  className={`flex h-9 flex-1 items-center justify-center rounded-full border text-[10px] transition ${
                    skinTone === tone.id
                      ? "border-white bg-white/10 text-white shadow-[0_0_25px_rgba(255,255,255,0.5)]"
                      : "border-white/10 bg-zinc-900/80 text-zinc-300 hover:border-white/40"
                  }`}
                >
                  <span
                    className="mr-1.5 h-4 w-4 rounded-full border border-black/30"
                    style={{ background: tone.color }}
                  />
                  {tone.label}
                </button>
              ))}
            </div>
          </div>

          {/* Background selection */}
          <div className="space-y-1.5">
            <div className="flex items-center gap-1.5 text-[11px] text-zinc-400">
              <SquareStack className="h-3.5 w-3.5" />
              <span>Select background</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {backgrounds.map((bg) => (
                <button
                  key={bg}
                  type="button"
                  onClick={() => setBackground(bg)}
                  className={`rounded-full px-3 py-1.5 text-[11px] transition ${
                    background === bg
                      ? "bg-white text-black shadow-[0_0_25px_rgba(255,255,255,0.5)]"
                      : "bg-zinc-900 text-zinc-200 hover:bg-zinc-800"
                  }`}
                >
                  {bg}
                </button>
              ))}
            </div>
          </div>

          {/* Pose selection */}
          <div className="space-y-1.5">
            <div className="flex items-center gap-1.5 text-[11px] text-zinc-400">
              <PersonStanding className="h-3.5 w-3.5" />
              <span>Select pose</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {poses.map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setPose(p)}
                  className={`rounded-full px-3 py-1.5 text-[11px] transition ${
                    pose === p
                      ? "bg-white text-black shadow-[0_0_25px_rgba(255,255,255,0.5)]"
                      : "bg-zinc-900 text-zinc-200 hover:bg-zinc-800"
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}


