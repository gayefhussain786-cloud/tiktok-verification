"use client";

import { useState, FormEvent } from "react";
import { motion } from "framer-motion";
import { Mail, Lock, UserPlus } from "lucide-react";

type Mode = "login" | "signup";

export default function AuthPage() {
  const [mode, setMode] = useState<Mode>("login");

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    // Auth wiring goes here (Supabase, NextAuth, etc.)
  };

  return (
    <div className="flex w-full flex-1 flex-col items-center justify-center">
      <motion.div
        initial={{ opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45 }}
        className="w-full max-w-md rounded-3xl border border-white/10 bg-zinc-950/90 p-5 shadow-[0_0_80px_rgba(0,0,0,1)] backdrop-blur-2xl"
      >
        <div className="mb-5 flex items-center justify-between gap-2">
          <div>
            <p className="text-xs uppercase tracking-[0.22em] text-zinc-500">
              Account
            </p>
            <h1 className="mt-1 text-xl font-semibold tracking-tight">
              {mode === "login" ? "Welcome back" : "Create your locker"}
            </h1>
            <p className="mt-1 text-xs text-zinc-400">
              One account for try-ons, wishlist and checkout.
            </p>
          </div>
        </div>

        <div className="mb-4 flex gap-1.5 rounded-full bg-zinc-900/80 p-1">
          <button
            type="button"
            onClick={() => setMode("login")}
            className={`flex-1 rounded-full px-3 py-1.5 text-xs transition ${
              mode === "login"
                ? "bg-white text-black shadow-[0_0_35px_rgba(255,255,255,0.7)]"
                : "text-zinc-400"
            }`}
          >
            Log in
          </button>
          <button
            type="button"
            onClick={() => setMode("signup")}
            className={`flex-1 rounded-full px-3 py-1.5 text-xs transition ${
              mode === "signup"
                ? "bg-white text-black shadow-[0_0_35px_rgba(255,255,255,0.7)]"
                : "text-zinc-400"
            }`}
          >
            Sign up
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          <div className="space-y-1.5">
            <label className="text-xs text-zinc-300" htmlFor="email">
              Email
            </label>
            <div className="flex items-center gap-2 rounded-2xl border border-white/10 bg-zinc-900/80 px-3 py-2">
              <Mail className="h-4 w-4 text-zinc-500" />
              <input
                id="email"
                type="email"
                required
                placeholder="you@studio.com"
                className="h-7 w-full bg-transparent text-sm text-white outline-none placeholder:text-zinc-600"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs text-zinc-300" htmlFor="password">
              Password
            </label>
            <div className="flex items-center gap-2 rounded-2xl border border-white/10 bg-zinc-900/80 px-3 py-2">
              <Lock className="h-4 w-4 text-zinc-500" />
              <input
                id="password"
                type="password"
                required
                placeholder="Minimum 8 characters"
                className="h-7 w-full bg-transparent text-sm text-white outline-none placeholder:text-zinc-600"
              />
            </div>
          </div>

          {mode === "signup" && (
            <div className="space-y-1.5">
              <label className="text-xs text-zinc-300" htmlFor="username">
                Username
              </label>
              <div className="flex items-center gap-2 rounded-2xl border border-white/10 bg-zinc-900/80 px-3 py-2">
                <UserPlus className="h-4 w-4 text-zinc-500" />
                <input
                  id="username"
                  type="text"
                  required
                  placeholder="janvi-lifts"
                  className="h-7 w-full bg-transparent text-sm text-white outline-none placeholder:text-zinc-600"
                />
              </div>
            </div>
          )}

          <button
            type="submit"
            className="mt-2 inline-flex w-full items-center justify-center rounded-full bg-white px-4 py-2.5 text-sm font-semibold text-black shadow-[0_0_45px_rgba(255,255,255,0.65)] transition hover:-translate-y-0.5 hover:shadow-[0_0_70px_rgba(255,255,255,0.8)]"
          >
            {mode === "login" ? "Continue" : "Create account"}
          </button>
        </form>

        <p className="mt-3 text-[10px] text-zinc-500">
          By continuing you agree to V-Try Studio&apos;s Terms and confirm you
          have read the Privacy Policy.
        </p>
      </motion.div>
    </div>
  );
}


