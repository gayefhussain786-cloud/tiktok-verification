"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Camera, UploadCloud, ShoppingBag } from "lucide-react";

export default function Home() {
  return (
    <div className="flex flex-1 flex-col gap-6 md:flex-row md:items-center md:gap-10">
      {/* Left content */}
      <div className="flex flex-1 flex-col justify-center space-y-4 md:space-y-6">
        <motion.h1
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-balance text-3xl font-semibold tracking-tight sm:text-4xl md:text-5xl"
        >
          Step into your{" "}
          <span className="bg-gradient-to-r from-zinc-100 via-white to-zinc-400 bg-clip-text text-transparent">
            gym fit
          </span>{" "}
          before it ships.
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="max-w-md text-sm text-zinc-400 sm:text-base"
        >
          V-Try Studio lets you preview performance fits on your body in seconds.
          Minimal, fast, and built for the new era of virtual try-ons.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.15 }}
          className="mt-2 flex flex-wrap gap-3"
        >
          <Link href="/try-on">
            <button className="group inline-flex items-center gap-2 rounded-full bg-white px-5 py-2.5 text-sm font-semibold text-black shadow-[0_0_40px_rgba(255,255,255,0.35)] transition hover:-translate-y-0.5 hover:shadow-[0_0_60px_rgba(255,255,255,0.5)]">
              <Camera className="h-4 w-4" />
              Start Try-On
            </button>
          </Link>
          <Link href="/upload">
            <button className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/5 px-4 py-2.5 text-sm font-medium text-zinc-100 backdrop-blur-xl transition hover:border-white/60 hover:bg-white/10">
              <UploadCloud className="h-4 w-4" />
              Upload Cloth
            </button>
          </Link>
          <Link href="/marketplace">
            <button className="inline-flex items-center gap-2 rounded-full border border-zinc-700 bg-black/40 px-4 py-2.5 text-xs font-medium text-zinc-300 backdrop-blur-xl transition hover:border-white/40 hover:text-white">
              <ShoppingBag className="h-4 w-4" />
              Browse Marketplace
            </button>
          </Link>
        </motion.div>
      </div>

      {/* Right camera preview panel */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.55, delay: 0.1 }}
        className="mt-6 flex flex-1 items-center justify-center md:mt-0"
      >
        <div className="relative w-full max-w-xs overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-b from-zinc-900/80 via-black to-zinc-950/90 p-2 shadow-[0_0_80px_rgba(0,0,0,0.8)] sm:max-w-sm">
          {/* Status pill */}
          <div className="mb-2 flex items-center justify-between px-1.5 text-[10px] text-zinc-400">
            <span className="flex items-center gap-1">
              <span className="relative flex h-1.5 w-1.5">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400/60 opacity-75" />
                <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-emerald-400" />
              </span>
              Live camera
            </span>
            <span>Studio · 60fps</span>
          </div>

          {/* Camera placeholder */}
          <div className="relative aspect-[9/16] w-full overflow-hidden rounded-2xl border border-white/5 bg-[radial-gradient(circle_at_10%_0%,#27272a,transparent_50%),radial-gradient(circle_at_90%_100%,#18181b,transparent_55%)]">
            <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(255,255,255,0.08),transparent_55%),linear-gradient(to_bottom,rgba(15,23,42,0.3),transparent_60%)] mix-blend-screen" />

            <div className="relative flex h-full flex-col items-center justify-center gap-4 px-6 text-center">
              <p className="text-xs font-medium tracking-wide text-zinc-300">
                Camera preview placeholder
              </p>
              <p className="text-[11px] text-zinc-500">
                Connect your webcam or mobile camera to see yourself in real time.
              </p>
            </div>
          </div>

          {/* Floating controls under preview */}
          <div className="-mb-1 mt-3 flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-white/10 bg-zinc-900/70 px-3 py-2.5 text-[11px] text-zinc-200 backdrop-blur-xl">
            <div className="flex items-center gap-1.5">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 shadow-[0_0_10px_rgba(74,222,128,0.8)]" />
              <span className="uppercase tracking-[0.2em] text-[9px] text-zinc-400">
                Ready
              </span>
            </div>
            <div className="flex gap-1.5">
              <span className="rounded-full bg-white/5 px-2 py-1 text-[10px] text-zinc-300">
                4K
              </span>
              <span className="rounded-full bg-white/5 px-2 py-1 text-[10px] text-zinc-300">
                Depth-Fit ON
              </span>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
