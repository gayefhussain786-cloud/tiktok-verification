"use client";

import { useState, ChangeEvent } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { UploadCloud, Image as ImageIcon, ArrowRight } from "lucide-react";

export default function UploadPage() {
  const router = useRouter();
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);

  const handleFileChange = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
  };

  const handleContinue = () => {
    router.push("/try-on");
  };

  return (
    <div className="flex w-full flex-1 flex-col gap-5 md:flex-row md:items-center md:gap-10">
      <div className="flex flex-1 flex-col gap-4">
        <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">
          Upload your{" "}
          <span className="bg-gradient-to-r from-zinc-50 via-white to-zinc-400 bg-clip-text text-transparent">
            next fit
          </span>
        </h1>
        <p className="max-w-md text-sm text-zinc-400 sm:text-base">
          Drop in product shots, flat-lays or screenshots. We&apos;ll align and
          prep them for realistic try-on in seconds.
        </p>

        <div className="mt-2 flex flex-col gap-2 text-xs text-zinc-500">
          <p>Supported: PNG, JPG, WEBP · Max 10MB</p>
          <p>Pro tip: upload on a solid background for the cleanest results.</p>
        </div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45 }}
        className="flex flex-1 items-center justify-center"
      >
        <div className="w-full max-w-md rounded-3xl border border-white/10 bg-zinc-950/90 p-4 shadow-[0_0_80px_rgba(0,0,0,0.9)] backdrop-blur-2xl">
          <label
            htmlFor="cloth-upload"
            className="group flex cursor-pointer flex-col items-center justify-center gap-3 rounded-2xl border border-dashed border-white/15 bg-zinc-900/60 px-6 py-10 text-center transition hover:border-white/40 hover:bg-zinc-900"
          >
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-white/5 text-white shadow-[0_0_40px_rgba(255,255,255,0.18)] group-hover:bg-white group-hover:text-black">
              <UploadCloud className="h-6 w-6" />
            </div>
            <div className="space-y-1">
              <p className="text-sm font-medium">
                Drag & drop your cloth image here
              </p>
              <p className="text-xs text-zinc-400">or tap to browse files</p>
            </div>
            <input
              id="cloth-upload"
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleFileChange}
            />
          </label>

          {/* Preview area */}
          <div className="mt-4 rounded-2xl border border-white/10 bg-zinc-900/80 p-3">
            <div className="mb-2 flex items-center gap-2 text-xs text-zinc-400">
              <ImageIcon className="h-4 w-4" />
              <span>Preview</span>
            </div>
            <div className="flex aspect-video items-center justify-center overflow-hidden rounded-xl border border-white/5 bg-zinc-950">
              {previewUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={previewUrl}
                  alt="Uploaded cloth preview"
                  className="h-full w-full object-contain"
                />
              ) : (
                <p className="text-[11px] text-zinc-500">
                  Your cloth image will appear here.
                </p>
              )}
            </div>
            <div className="mt-2 flex items-center justify-between text-[11px] text-zinc-400">
              <span className="truncate">
                {fileName ? fileName : "No file selected yet"}
              </span>
              <span>Ready for try-on</span>
            </div>
          </div>

          <button
            type="button"
            onClick={handleContinue}
            disabled={!previewUrl}
            className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-full bg-white px-4 py-2.5 text-sm font-semibold text-black shadow-[0_0_40px_rgba(255,255,255,0.4)] transition hover:-translate-y-0.5 hover:shadow-[0_0_60px_rgba(255,255,255,0.6)] disabled:cursor-not-allowed disabled:bg-zinc-700 disabled:text-zinc-300 disabled:shadow-none"
          >
            Continue to Try-On
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </motion.div>
    </div>
  );
}

"use client";

import { useState } from "react";
import { Upload, ChevronDown } from "lucide-react";

export default function UploadCloth() {
  const [image, setImage] = useState<string | null>(null);
  const [sizeOpen, setSizeOpen] = useState(false);
  const [selectedSize, setSelectedSize] = useState("Select Size");

  const sizes = ["XS", "S", "M", "L", "XL", "XXL"];

  const handleImageUpload = (e: any) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event: any) => setImage(event.target.result);
    reader.readAsDataURL(file);
  };

  return (
    <div className="w-full min-h-screen bg-black text-white flex flex-col px-6 pt-6">
      
      {/* HEADER */}
      <header className="w-full py-4 border-b border-neutral-800 flex items-center justify-between">
        <h1 className="text-3xl font-extrabold">
          Upload <span className="text-yellow-400">Cloth</span>
        </h1>
      </header>

      {/* MAIN */}
      <div className="mt-8">
        <p className="text-neutral-400 mb-3">
          Add your product details to publish it on marketplace
        </p>

        {/* UPLOAD IMAGE BOX */}
        <label className="w-full h-64 border border-neutral-700 bg-neutral-900 rounded-2xl flex flex-col items-center justify-center cursor-pointer hover:bg-neutral-800 transition">
          {image ? (
            <img src={image} className="w-full h-full object-cover rounded-2xl" />
          ) : (
            <>
              <Upload size={36} className="text-neutral-400 mb-3" />
              <span className="text-neutral-400">Click to upload image</span>
            </>
          )}

          <input type="file" className="hidden" accept="image/*" onChange={handleImageUpload} />
        </label>

        {/* INPUT FIELDS */}
        <div className="mt-8 space-y-5">
          <input
            type="text"
            placeholder="Product Name"
            className="w-full bg-neutral-900 border border-neutral-700 rounded-xl p-4 outline-none text-white"
          />

          <textarea
            placeholder="Product Description"
            rows={4}
            className="w-full bg-neutral-900 border border-neutral-700 rounded-xl p-4 outline-none text-white resize-none"
          />

          <input
            type="number"
            placeholder="Price (₹)"
            className="w-full bg-neutral-900 border border-neutral-700 rounded-xl p-4 outline-none text-white"
          />

          {/* SIZE DROPDOWN */}
          <div className="relative">
            <button
              onClick={() => setSizeOpen(!sizeOpen)}
              className="w-full bg-neutral-900 border border-neutral-700 rounded-xl p-4 flex justify-between items-center"
            >
              {selectedSize}
              <ChevronDown size={18} />
            </button>

            {sizeOpen && (
              <div className="absolute w-full mt-2 bg-neutral-900 border border-neutral-700 rounded-xl p-2 z-20">
                {sizes.map((s) => (
                  <button
                    key={s}
                    onClick={() => {
                      setSelectedSize(s);
                      setSizeOpen(false);
                    }}
                    className="w-full text-left px-4 py-2 hover:bg-neutral-800 rounded-lg transition"
                  >
                    {s}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* SUBMIT BUTTON */}
        <button
          className="w-full bg-yellow-400 text-black text-lg font-semibold py-4 rounded-2xl mt-8 hover:bg-yellow-300 transition"
        >
          Upload & Publish
        </button>
      </div>
    </div>
  );
}
