// @ts-nocheck

import OpenAI from "openai";

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export const runtime = "nodejs";

export async function POST(request: Request) {
  try {
    const formData = await request.formData();
    const file = formData.get("audio");

    if (!file || !(file instanceof Blob)) {
      return new Response(
        JSON.stringify({ error: "Missing audio file payload." }),
        { status: 400 }
      );
    }

    // Convert file to Node.js compatible buffer
    const arrayBuffer = await file.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    // 1. Transcribe speech to text using OpenAI (Realtime stack compatible)
    const transcription = await client.audio.transcriptions.create({
      model: "gpt-4o-mini-transcribe",
      file: new File([buffer], "input.webm"),
    });

    const transcriptText =
      (typeof transcription.text === "string"
        ? transcription.text
        : "") || "";

    // 2. Generate a friendly assistant reply as "Janvi"
    const chat = await client.chat.completions.create({
      model: "gpt-4.1-mini",
      messages: [
        {
          role: "system",
          content:
            "You are Janvi, a friendly, high-energy voice assistant inside a virtual fashion try-on app. You can help the user move between pages (home, upload cloth, try-on, marketplace, login) and give short, confident responses.",
        },
        {
          role: "user",
          content: transcriptText || "Say hello and introduce yourself.",
        },
      ],
      max_tokens: 120,
    });

    const reply =
      chat.choices[0]?.message?.content ??
      "Hey, I’m Janvi. I’m here to help you explore fits and jump between try-on, upload and marketplace.";

    // 3. Generate short audio response (Realtime audio stack)
    const speech = await client.audio.speech.create({
      model: "gpt-4o-mini-tts",
      voice: "alloy",
      input: reply,
      format: "mp3",
    });

    const audioBuffer = Buffer.from(await speech.arrayBuffer());
    const base64 = audioBuffer.toString("base64");
    const audioUrl = `data:audio/mp3;base64,${base64}`;

    return new Response(
      JSON.stringify({
        transcript: transcriptText,
        reply,
        audioUrl,
      }),
      {
        status: 200,
        headers: {
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    console.error("Voice route error:", error);
    return new Response(
      JSON.stringify({
        error: "Voice assistant error",
      }),
      { status: 500 }
    );
  }
}


