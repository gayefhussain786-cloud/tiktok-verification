export async function POST(req: Request) {
  try {
    const body = (await req.json().catch(() => null)) as
      | { message?: string }
      | null;
    const message = body?.message?.trim();

    if (!message) {
      return new Response(JSON.stringify({ error: "Missing 'message' in body" }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      });
    }

    const apiKey = process.env.GROQ_API_KEY;
    if (!apiKey) {
      return new Response(JSON.stringify({ error: "GROQ_API_KEY not configured" }), {
        status: 500,
        headers: { "Content-Type": "application/json" },
      });
    }

    const groqRes = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "mixtral-8x7b-32768",
        messages: [
          {
            role: "system",
            content:
              "You are Zippi, a concise, friendly assistant inside a virtual try-on app. Keep replies short (one or two sentences) and include navigation hints like 'opening marketplace', 'starting try on', or 'uploading cloth' when appropriate.",
          },
          { role: "user", content: message },
        ],
        max_tokens: 160,
      }),
    });

    if (!groqRes.ok) {
      const text = await groqRes.text();
      console.error("Groq API error:", text);
      return new Response(JSON.stringify({ error: "Groq API error" }), {
        status: 500,
        headers: { "Content-Type": "application/json" },
      });
    }

    const data = (await groqRes.json()) as any;
    const reply: string =
      data?.choices?.[0]?.message?.content?.trim() ??
      "Zippi here. I can open marketplace, start try on, or help you upload cloth.";

    return new Response(JSON.stringify({ reply }), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Zippi route error:", error);
    return new Response(JSON.stringify({ error: "Internal server error" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
}


