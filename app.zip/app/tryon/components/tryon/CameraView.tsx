import React, { useEffect, useRef } from "react";

const CameraView = ({ selectedCloth, onPoseDetected, isProcessing }) => {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const overlayCanvasRef = useRef(null);

  useEffect(() => {
    const startCamera = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: "user" },
          audio: false,
        });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.onloadedmetadata = () => {
            videoRef.current.play();
          };
        }
      } catch (err) {
        console.error("Error accessing webcam:", err);
      }
    };

    startCamera();
  }, []);

  useEffect(() => {
    const drawLoop = () => {
      const canvas = canvasRef.current;
      const overlay = overlayCanvasRef.current;
      const video = videoRef.current;

      if (!canvas || !overlay || !video) return;

      const ctx = canvas.getContext("2d");
      const overlayCtx = overlay.getContext("2d");

      // set fixed dimensions to match outer frame
      const TARGET_WIDTH = 1280;
      const TARGET_ASPECT = 820 / 520;

      canvas.width = TARGET_WIDTH;
      canvas.height = Math.round(TARGET_WIDTH / TARGET_ASPECT);
      overlay.width = canvas.width;
      overlay.height = canvas.height;

      canvas.style.width = "100%";
      canvas.style.height = "100%";
      overlay.style.width = "100%";
      overlay.style.height = "100%";

      const render = () => {
        if (video.readyState >= 2) {
          ctx.save();
          ctx.scale(-1, 1); // Mirror horizontally
          ctx.translate(-canvas.width, 0);
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          ctx.restore();

          // You can draw overlay here too (fake cloth for testing)
          overlayCtx.clearRect(0, 0, overlay.width, overlay.height);
          if (selectedCloth) {
            overlayCtx.fillStyle = "rgba(255, 255, 0, 0.3)";
            overlayCtx.fillRect(
              overlay.width / 2 - 100,
              overlay.height / 2 - 100,
              200,
              150
            );
          }
        }

        requestAnimationFrame(render);
      };

      render();
    };

    drawLoop();
  }, [selectedCloth]);

  return (
    <div className="relative w-full h-full">
      {/* Hidden video */}
      <video
        ref={videoRef}
        playsInline
        muted
        className="hidden"
      />

      {/* Base canvas (shows mirrored camera) */}
      <canvas ref={canvasRef} className="absolute top-0 left-0 w-full h-full z-10 rounded-3xl" />

      {/* Overlay canvas (draw clothes/pose) */}
      <canvas ref={overlayCanvasRef} className="absolute top-0 left-0 w-full h-full z-20 rounded-3xl" />
    </div>
  );
};

export default CameraView;
