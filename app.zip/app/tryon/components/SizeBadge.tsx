"use client";

export default function SizeBadge({
  size,
  width,
}: {
  size: string;
  width: number | undefined;
}) {
  return (
    <div className="bg-white/10 border border-yellow-500 px-6 py-2 rounded-xl text-center shadow-[0_0_15px_#ffd500]">
      <p className="text-yellow-300 font-bold text-lg">Perfect Fit</p>
      <p className="text-sm">Suggested Size: {size}</p>
      <p className="text-xs text-gray-300">
        {width ? width.toFixed(1) : "--"} cm
      </p>
    </div>
  );
}
