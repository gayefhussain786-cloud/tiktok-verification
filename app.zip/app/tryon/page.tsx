"use client";

import { useRef } from "react";
import ControlPanel from "@/components/ControlPanel";
import CameraView from "@/components/CameraView";
import ClothOverlay from "@/components/ClothOverlay";
import { useCamera } from "@/engine/useCamera";
import { usePoseClothFit } from "@/engine/usePoseClothFit";
import { useClothUpload } from "@/engine/useClothUpload";

export default function TryOnPage() {
  const videoRef = useRef<HTMLVideoElement>(null);

  // start camera
  useCamera(videoRef, true);

  // clothing upload hook
  const { clothUrl, handleUpload } = useClothUpload();

  // pose-based cloth fitting (only active when cloth uploaded)
  const { xPercent, yPercent, scale } = usePoseClothFit(
    videoRef,
    !!clothUrl
  );

  return (
    <div className="flex min-h-[calc(100vh-64px)] pt-6">
      {/* LEFT CONTROL BAR */}
      <ControlPanel />

      {/* MAIN AREA */}
      <div className="flex-1 flex flex-col items-center justify-start">
        {/* CAMERA + CLOTH CONTAINER */}
        <div className="relative w-[380px] h-[500px] sm:w-[480px] sm:h-[640px] bg-neutral-900 border border-white/10 rounded-3xl overflow-hidden">
          <CameraView videoRef={videoRef} />
          <ClothOverlay
            clothUrl={clothUrl}
            xPercent={xPercent}
            yPercent={yPercent}
            scale={scale}
          />
        </div>

        {/* UPLOAD BUTTON */}
        <label className="mt-6 cursor-pointer bg-yellow-400 text-black px-8 py-3 rounded-xl font-semibold hover:bg-yellow-300 transition">
          Upload Clothing
          <input
            type="file"
            accept="image/png,image/jpeg"
            className="hidden"
            onChange={handleUpload}
          />
        </label>
      </div>
    </div>
  );
}
