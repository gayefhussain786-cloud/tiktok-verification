export default function ProfilePage() {
  return (
    <div className="max-w-5xl mx-auto px-4 py-10">
      <div className="flex items-center gap-6">
        <div className="w-20 h-20 rounded-full bg-white/10 flex items-center justify-center text-2xl font-bold">
          R
        </div>

        <div>
          <h1 className="text-3xl font-extrabold">Rakshit Raj</h1>
          <p className="text-gray-400 text-sm">abcrakshit123@gmail.com</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="mt-10 flex gap-6 border-b border-white/10 pb-2">
        <button className="text-yellow-400 font-bold border-b-2 border-yellow-400 pb-2">Try-Ons</button>
        <button className="text-gray-400 hover:text-white pb-2">Wishlist</button>
      </div>

      {/* Try-On History Empty State */}
      <div className="flex flex-col items-center justify-center text-center mt-14">
        <div className="w-16 h-16 bg-white/5 rounded-full border border-white/10 flex items-center justify-center">
          <span className="text-3xl">👕</span>
        </div>

        <h2 className="text-xl font-bold mt-4">No Try-Ons Yet</h2>
        <p className="text-gray-400 text-sm max-w-sm mt-2">
          Try clothing items using our real-time AI virtual try-on system. Once done, they will appear here.
        </p>

        <a href="/tryon" className="nike-btn mt-6">Start Try-On</a>
      </div>
    </div>
  );
}
