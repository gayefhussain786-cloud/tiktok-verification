"use client";

import React, { useState } from "react";

export default function AIModelGeneratorPage() {
  const [modelType, setModelType] = useState("Female Model");
  const [pose, setPose] = useState("Standing Front");
  const [background, setBackground] = useState("Studio White");
  const [previewUrl] = useState(
    "https://images.pexels.com/photos/1855581/pexels-photo-1855581.jpeg?auto=compress&cs=tinysrgb&w=800"
  );

  return (
    <div className="space-y-6 md:space-y-8">
      <div className="space-y-2">
        <h1 className="text-2xl md:text-3xl font-semibold">
          AI Model Generator
        </h1>
        <p className="text-sm text-white/60 max-w-xl">
          Upload your clothing and let AI create professional model photos for
          your products.
        </p>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        {/* Left: upload clothing block */}
        <div className="rounded-3xl border border-white/10 bg-black/60 p-4 md:p-6 space-y-4">
          <h2 className="text-sm font-semibold mb-1">Upload Clothing</h2>
          <div className="aspect-[4/5] rounded-2xl border border-dashed border-white/20 bg-white/5 flex flex-col items-center justify-center gap-2 text-sm text-white/60">
            <span className="text-3xl">⬆</span>
            <p>Drop clothing image here</p>
            <p className="text-[11px] text-white/40">PNG, JPG up to 10MB</p>
          </div>

          {/* Model Settings */}
          <div className="space-y-3 pt-2">
            <h3 className="text-sm font-semibold">Model Settings</h3>

            <div className="space-y-1.5">
              <label className="text-[11px] text-white/70">Model Type</label>
              <select
                value={modelType}
                onChange={(e) => setModelType(e.target.value)}
                className="w-full rounded-2xl border border-white/10 bg-white/5 px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-yellow-400"
              >
                <option>Female Model</option>
                <option>Male Model</option>
                <option>Plus Size Model</option>
                <option>Teen Model</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-[11px] text-white/70">Pose</label>
              <select
                value={pose}
                onChange={(e) => setPose(e.target.value)}
                className="w-full rounded-2xl border border-white/10 bg-white/5 px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-yellow-400"
              >
                <option>Standing Front</option>
                <option>Standing Side</option>
                <option>Walking Pose</option>
                <option>Hands on Hips</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-[11px] text-white/70">Background</label>
              <select
                value={background}
                onChange={(e) => setBackground(e.target.value)}
                className="w-full rounded-2xl border border-white/10 bg-white/5 px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-yellow-400"
              >
                <option>Studio White</option>
                <option>Pastel Wall</option>
                <option>Outdoor Street</option>
                <option>Brand Color</option>
              </select>
            </div>

            <button className="mt-2 w-full rounded-full bg-yellow-400 py-2.5 text-sm font-semibold text-black shadow-[0_0_24px_rgba(250,204,21,0.45)] hover:bg-yellow-300">
              ✨ Generate Model Photo
            </button>
          </div>
        </div>

        {/* Right: Generated result */}
        <div className="rounded-3xl border border-white/10 bg-black/60 p-4 md:p-6 flex flex-col">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold">Generated Result</h2>
            <button className="rounded-full border border-white/15 bg-white/5 px-3 py-1 text-xs text-white/70 hover:bg-white/10">
              ⬇ Download
            </button>
          </div>
          <div className="flex-1 rounded-3xl bg-white/5 overflow-hidden flex items-center justify-center">
            <img
              src={previewUrl}
              alt="Model preview"
              className="h-full w-full object-cover"
            />
          </div>

          <div className="mt-4 text-[11px] text-white/50 space-y-1">
            <p className="font-semibold text-white/70">Tips for best results</p>
            <ul className="list-disc list-inside space-y-0.5">
              <li>Use high-quality clothing images</li>
              <li>Plain background works best</li>
              <li>Ensure the full garment is visible</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
