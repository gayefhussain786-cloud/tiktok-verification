import React, { useRef, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { motion } from 'framer-motion';
import { 
  Camera, 
  Sparkles, 
  ShoppingBag, 
  ChevronRight, 
  Play,
  Zap,
  Shield,
  Globe
} from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';

export default function Home() {
  const videoRef = useRef(null);
  const [cameraActive, setCameraActive] = useState(false);

  const { data: featuredItems = [] } = useQuery({
    queryKey: ['featuredClothing'],
    queryFn: () => base44.entities.ClothingItem.filter({ is_featured: true }, '-created_date', 4),
  });

  useEffect(() => {
    const startCamera = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ 
          video: { facingMode: 'user', width: 640, height: 480 } 
        });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          setCameraActive(true);
        }
      } catch (err) {
        console.log('Camera not available');
      }
    };
    startCamera();
    
    return () => {
      if (videoRef.current?.srcObject) {
        videoRef.current.srcObject.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const features = [
    { icon: Zap, title: 'Real-Time Try-On', desc: 'Instant virtual fitting' },
    { icon: Shield, title: 'AI Powered', desc: 'Smart body tracking' },
    { icon: Globe, title: 'Any Device', desc: 'Works everywhere' },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center overflow-hidden">
        {/* Background gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-[#0A0A0A] via-[#141414] to-[#0A0A0A]" />
        
        {/* Animated grid */}
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0" style={{
            backgroundImage: `linear-gradient(rgba(255,208,47,0.1) 1px, transparent 1px), 
                             linear-gradient(90deg, rgba(255,208,47,0.1) 1px, transparent 1px)`,
            backgroundSize: '60px 60px'
          }} />
        </div>

        <div className="relative z-10 w-full max-w-7xl mx-auto px-4 md:px-6 py-12">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center lg:text-left"
            >
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="inline-flex items-center gap-2 px-4 py-2 bg-[#FFD02F]/10 border border-[#FFD02F]/20 rounded-full mb-6"
              >
                <Sparkles size={16} className="text-[#FFD02F]" />
                <span className="text-[#FFD02F] text-sm font-medium">AI-Powered Virtual Try-On</span>
              </motion.div>

              <h1 className="text-5xl md:text-7xl font-black leading-none mb-6">
                <span className="text-white">Try Before</span>
                <br />
                <span className="text-[#FFD02F]">You Buy</span>
              </h1>

              <p className="text-white/60 text-lg md:text-xl mb-8 max-w-md mx-auto lg:mx-0">
                Experience clothes virtually with real-time AI body tracking. 
                No more guessing your perfect fit.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <Link to={createPageUrl('TryOn')}>
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="w-full sm:w-auto px-8 py-4 bg-[#FFD02F] text-black rounded-2xl font-bold text-lg flex items-center justify-center gap-3 shadow-lg shadow-[#FFD02F]/20"
                  >
                    <Camera size={22} />
                    Start Try-On
                  </motion.button>
                </Link>
                
                <Link to={createPageUrl('Marketplace')}>
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="w-full sm:w-auto px-8 py-4 bg-white/5 border border-white/10 text-white rounded-2xl font-semibold text-lg flex items-center justify-center gap-3 hover:bg-white/10 transition-colors"
                  >
                    <ShoppingBag size={22} />
                    Browse Shop
                  </motion.button>
                </Link>
              </div>

              {/* Features */}
              <div className="mt-12 grid grid-cols-3 gap-4">
                {features.map((feat, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 + i * 0.1 }}
                    className="text-center lg:text-left"
                  >
                    <feat.icon size={24} className="text-[#FFD02F] mx-auto lg:mx-0 mb-2" />
                    <p className="text-white text-sm font-semibold">{feat.title}</p>
                    <p className="text-white/40 text-xs">{feat.desc}</p>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            {/* Right - Camera Preview */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="relative"
            >
              <div className="relative aspect-[3/4] max-w-md mx-auto rounded-3xl overflow-hidden bg-[#141414] border-2 border-white/10">
                {/* Camera Feed */}
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className="absolute inset-0 w-full h-full object-cover transform scale-x-[-1]"
                />
                
                {/* Overlay */}
                {!cameraActive && (
                  <div className="absolute inset-0 flex items-center justify-center bg-[#141414]">
                    <div className="text-center">
                      <div className="w-20 h-20 bg-[#FFD02F]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Camera size={32} className="text-[#FFD02F]" />
                      </div>
                      <p className="text-white/60">Camera Preview</p>
                    </div>
                  </div>
                )}

                {/* Scanning Effect */}
                {cameraActive && (
                  <motion.div
                    animate={{ y: ['0%', '100%', '0%'] }}
                    transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
                    className="absolute left-0 right-0 h-1 bg-gradient-to-r from-transparent via-[#FFD02F] to-transparent"
                  />
                )}

                {/* Corner Markers */}
                <div className="absolute top-4 left-4 w-8 h-8 border-t-2 border-l-2 border-[#FFD02F] rounded-tl-lg" />
                <div className="absolute top-4 right-4 w-8 h-8 border-t-2 border-r-2 border-[#FFD02F] rounded-tr-lg" />
                <div className="absolute bottom-4 left-4 w-8 h-8 border-b-2 border-l-2 border-[#FFD02F] rounded-bl-lg" />
                <div className="absolute bottom-4 right-4 w-8 h-8 border-b-2 border-r-2 border-[#FFD02F] rounded-br-lg" />

                {/* Status Badge */}
                <div className="absolute top-6 left-1/2 -translate-x-1/2">
                  <div className={`flex items-center gap-2 px-4 py-2 rounded-full ${
                    cameraActive ? 'bg-green-500/20 border border-green-500/30' : 'bg-red-500/20 border border-red-500/30'
                  }`}>
                    <div className={`w-2 h-2 rounded-full ${
                      cameraActive ? 'bg-green-500 animate-pulse' : 'bg-red-500'
                    }`} />
                    <span className={`text-xs font-medium ${
                      cameraActive ? 'text-green-400' : 'text-red-400'
                    }`}>
                      {cameraActive ? 'Camera Active' : 'Camera Off'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Floating Elements */}
              <motion.div
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 3, repeat: Infinity }}
                className="absolute -right-4 top-20 bg-[#1A1A1A] border border-white/10 rounded-2xl p-4 shadow-xl"
              >
                <p className="text-[#FFD02F] text-sm font-bold">AI Detection</p>
                <p className="text-white/40 text-xs">Body tracking active</p>
              </motion.div>

              <motion.div
                animate={{ y: [0, 10, 0] }}
                transition={{ duration: 3, repeat: Infinity, delay: 1.5 }}
                className="absolute -left-4 bottom-32 bg-[#1A1A1A] border border-white/10 rounded-2xl p-4 shadow-xl"
              >
                <p className="text-green-400 text-sm font-bold">Perfect Fit</p>
                <p className="text-white/40 text-xs">Size: Medium</p>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Featured Items Section */}
      {featuredItems.length > 0 && (
        <section className="py-16 px-4 md:px-6">
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h2 className="text-2xl md:text-3xl font-bold text-white">Featured Items</h2>
                <p className="text-white/40 mt-1">Try them on virtually</p>
              </div>
              <Link 
                to={createPageUrl('Marketplace')}
                className="flex items-center gap-1 text-[#FFD02F] font-medium hover:gap-2 transition-all"
              >
                View All <ChevronRight size={18} />
              </Link>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {featuredItems.map((item, i) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                >
                  <Link to={`${createPageUrl('ProductDetail')}?id=${item.id}`}>
                    <div className="group bg-[#141414] rounded-2xl overflow-hidden border border-white/5 hover:border-[#FFD02F]/30 transition-all">
                      <div className="aspect-square bg-[#1A1A1A] relative overflow-hidden">
                        {item.image_url ? (
                          <img 
                            src={item.image_url} 
                            alt={item.name}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <ShoppingBag size={40} className="text-white/20" />
                          </div>
                        )}
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                        <motion.button
                          whileTap={{ scale: 0.95 }}
                          className="absolute bottom-3 left-3 right-3 py-2.5 bg-[#FFD02F] text-black rounded-xl font-semibold text-sm opacity-0 group-hover:opacity-100 transition-all translate-y-2 group-hover:translate-y-0"
                        >
                          Try On
                        </motion.button>
                      </div>
                      <div className="p-4">
                        <p className="text-white font-semibold truncate">{item.name}</p>
                        <p className="text-[#FFD02F] font-bold">${item.price?.toFixed(2)}</p>
                      </div>
                    </div>
                  </Link>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* CTA Section */}
      <section className="py-16 px-4 md:px-6">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="relative bg-gradient-to-br from-[#FFD02F] to-[#FFA500] rounded-3xl p-8 md:p-12 overflow-hidden"
          >
            {/* Background Pattern */}
            <div className="absolute inset-0 opacity-10">
              <div className="absolute inset-0" style={{
                backgroundImage: `radial-gradient(circle at 2px 2px, black 1px, transparent 0)`,
                backgroundSize: '24px 24px'
              }} />
            </div>

            <div className="relative z-10 text-center">
              <h2 className="text-3xl md:text-4xl font-black text-black mb-4">
                Ready to Transform Shopping?
              </h2>
              <p className="text-black/70 text-lg mb-8 max-w-md mx-auto">
                Start your virtual try-on experience now and find your perfect fit instantly.
              </p>
              <Link to={createPageUrl('TryOn')}>
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="px-10 py-4 bg-black text-white rounded-2xl font-bold text-lg inline-flex items-center gap-3"
                >
                  <Play size={20} fill="white" />
                  Launch Try-On
                </motion.button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}