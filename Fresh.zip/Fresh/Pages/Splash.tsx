import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { createPageUrl } from '../utils';

export default function Splash() {
  const [phase, setPhase] = useState('bomb'); // bomb, sorry, coming-soon, redirect
  
  useEffect(() => {
    const timers = [
      setTimeout(() => setPhase('sorry'), 1500),
      setTimeout(() => setPhase('coming-soon'), 3500),
      setTimeout(() => {
        window.location.href = createPageUrl('Home');
      }, 6000)
    ];
    return () => timers.forEach(clearTimeout);
  }, []);

  return (
    <div className="min-h-screen bg-[#FFD02F] flex items-center justify-center overflow-hidden">
      <AnimatePresence mode="wait">
        {phase === 'bomb' && (
          <motion.div
            key="bomb"
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 3, opacity: 0 }}
            transition={{ duration: 0.5 }}
            className="relative"
          >
            {/* Bomb emoji with explosion effect */}
            <motion.div
              animate={{
                scale: [1, 1.1, 1, 1.2, 1],
                rotate: [0, -5, 5, -5, 0]
              }}
              transition={{ duration: 0.8, repeat: 1 }}
              className="text-[150px]"
            >
              💣
            </motion.div>
            
            {/* Explosion particles */}
            {[...Array(12)].map((_, i) => (
              <motion.div
                key={i}
                initial={{ scale: 0, x: 0, y: 0, opacity: 1 }}
                animate={{
                  scale: [0, 1.5, 0],
                  x: Math.cos(i * 30 * Math.PI / 180) * 150,
                  y: Math.sin(i * 30 * Math.PI / 180) * 150,
                  opacity: [1, 1, 0]
                }}
                transition={{ duration: 1, delay: 0.8 }}
                className="absolute top-1/2 left-1/2 w-8 h-8 bg-orange-500 rounded-full"
                style={{ marginLeft: -16, marginTop: -16 }}
              />
            ))}
          </motion.div>
        )}

        {phase === 'sorry' && (
          <motion.div
            key="sorry"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            transition={{ duration: 0.5 }}
            className="text-center px-8"
          >
            <motion.p 
              className="text-black text-3xl md:text-5xl font-bold mb-4"
              style={{ fontFamily: 'Inter, sans-serif' }}
            >
              Sorry!!
            </motion.p>
            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="text-black/80 text-xl md:text-2xl"
            >
              My co-founder threw it 😣
            </motion.p>
          </motion.div>
        )}

        {phase === 'coming-soon' && (
          <motion.div
            key="coming-soon"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center px-8"
          >
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.2 }}
            >
              <h1 className="text-black text-5xl md:text-7xl font-black tracking-tight mb-2">
                Zip<span className="text-white">RIGHT</span>
              </h1>
              <div className="h-1 w-24 bg-black mx-auto mb-6" />
              <p className="text-black text-xl md:text-2xl font-medium">
                Coming Soon
              </p>
              <motion.div
                animate={{ opacity: [0.5, 1, 0.5] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="mt-8 flex justify-center gap-2"
              >
                {[0, 1, 2].map(i => (
                  <motion.div
                    key={i}
                    animate={{ scale: [1, 1.3, 1] }}
                    transition={{ duration: 0.6, delay: i * 0.2, repeat: Infinity }}
                    className="w-3 h-3 bg-black rounded-full"
                  />
                ))}
              </motion.div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}