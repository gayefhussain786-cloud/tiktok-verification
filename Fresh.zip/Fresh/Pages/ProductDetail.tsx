import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { motion } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  ArrowLeft, 
  Camera, 
  Heart, 
  Share2, 
  ShoppingBag,
  Check,
  Ruler,
  Star,
  ChevronRight
} from 'lucide-react';

export default function ProductDetail() {
  const queryClient = useQueryClient();
  const urlParams = new URLSearchParams(window.location.search);
  const productId = urlParams.get('id');
  
  const [selectedSize, setSelectedSize] = useState(null);
  const [selectedColor, setSelectedColor] = useState(null);
  const [isLiked, setIsLiked] = useState(false);

  // Fetch product
  const { data: product, isLoading } = useQuery({
    queryKey: ['product', productId],
    queryFn: async () => {
      const items = await base44.entities.ClothingItem.filter({ id: productId });
      return items[0];
    },
    enabled: !!productId
  });

  // Fetch related products
  const { data: relatedProducts = [] } = useQuery({
    queryKey: ['relatedProducts', product?.category],
    queryFn: () => base44.entities.ClothingItem.filter(
      { category: product.category }, 
      '-created_date', 
      4
    ),
    enabled: !!product?.category
  });

  // Add to wishlist
  const addToWishlistMutation = useMutation({
    mutationFn: (data) => base44.entities.Wishlist.create(data),
    onSuccess: () => queryClient.invalidateQueries(['wishlist'])
  });

  useEffect(() => {
    if (product?.sizes?.length > 0 && !selectedSize) {
      setSelectedSize(product.sizes[0]);
    }
    if (product?.colors?.length > 0 && !selectedColor) {
      setSelectedColor(product.colors[0]);
    }
  }, [product]);

  const handleLike = async () => {
    setIsLiked(!isLiked);
    if (!isLiked) {
      await addToWishlistMutation.mutateAsync({ clothing_item_id: productId });
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: product?.name,
          text: `Check out ${product?.name} on ZipRIGHT!`,
          url: window.location.href
        });
      } catch (err) {
        console.log('Share cancelled');
      }
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#0A0A0A] flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-[#FFD02F] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-[#0A0A0A] flex items-center justify-center p-4">
        <div className="text-center">
          <ShoppingBag size={48} className="text-white/20 mx-auto mb-4" />
          <p className="text-white text-xl font-bold mb-2">Product not found</p>
          <Link to={createPageUrl('Marketplace')} className="text-[#FFD02F]">
            Back to Shop
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0A0A0A]">
      {/* Back Button */}
      <div className="sticky top-16 md:top-20 z-30 bg-[#0A0A0A]/95 backdrop-blur-xl border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 md:px-6 py-4">
          <Link 
            to={createPageUrl('Marketplace')}
            className="inline-flex items-center gap-2 text-white/60 hover:text-white transition-colors"
          >
            <ArrowLeft size={20} />
            <span>Back to Shop</span>
          </Link>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-6 py-8">
        <div className="grid md:grid-cols-2 gap-8 md:gap-12">
          {/* Product Image */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="relative"
          >
            <div className="aspect-[3/4] bg-[#141414] rounded-3xl overflow-hidden">
              {product.image_url ? (
                <img 
                  src={product.image_url} 
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <ShoppingBag size={80} className="text-white/10" />
                </div>
              )}
            </div>

            {/* Featured Badge */}
            {product.is_featured && (
              <div className="absolute top-4 left-4 px-3 py-1.5 bg-[#FFD02F] rounded-xl flex items-center gap-1.5">
                <Star size={14} className="text-black fill-black" />
                <span className="text-black text-sm font-bold">Featured</span>
              </div>
            )}

            {/* Quick Actions */}
            <div className="absolute top-4 right-4 flex gap-2">
              <motion.button
                whileTap={{ scale: 0.9 }}
                onClick={handleLike}
                className={`w-12 h-12 rounded-xl flex items-center justify-center backdrop-blur-sm ${
                  isLiked ? 'bg-red-500' : 'bg-black/50'
                }`}
              >
                <Heart 
                  size={22} 
                  className={isLiked ? 'text-white fill-white' : 'text-white'} 
                />
              </motion.button>
              
              <motion.button
                whileTap={{ scale: 0.9 }}
                onClick={handleShare}
                className="w-12 h-12 bg-black/50 backdrop-blur-sm rounded-xl flex items-center justify-center"
              >
                <Share2 size={22} className="text-white" />
              </motion.button>
            </div>
          </motion.div>

          {/* Product Info */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            {/* Brand & Category */}
            <div className="flex items-center gap-3">
              {product.brand && (
                <span className="px-3 py-1 bg-white/5 rounded-lg text-white/60 text-sm font-medium">
                  {product.brand}
                </span>
              )}
              <span className="text-white/40 text-sm">
                {product.category?.replace(/_/g, ' ')}
              </span>
            </div>

            {/* Name & Price */}
            <div>
              <h1 className="text-3xl md:text-4xl font-black text-white mb-3">
                {product.name}
              </h1>
              <p className="text-[#FFD02F] text-3xl font-bold">
                ${product.price?.toFixed(2)}
              </p>
            </div>

            {/* Description */}
            {product.description && (
              <p className="text-white/50 text-lg leading-relaxed">
                {product.description}
              </p>
            )}

            {/* Size Selection */}
            {product.sizes?.length > 0 && (
              <div>
                <div className="flex items-center justify-between mb-3">
                  <p className="text-white font-semibold">Size</p>
                  <button className="text-[#FFD02F] text-sm flex items-center gap-1">
                    <Ruler size={14} />
                    Size Guide
                  </button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {product.sizes.map(size => (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`min-w-[60px] py-3 rounded-xl font-semibold transition-all ${
                        selectedSize === size
                          ? 'bg-[#FFD02F] text-black'
                          : 'bg-white/5 text-white hover:bg-white/10'
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Color Selection */}
            {product.colors?.length > 0 && (
              <div>
                <p className="text-white font-semibold mb-3">Color</p>
                <div className="flex flex-wrap gap-3">
                  {product.colors.map(color => (
                    <button
                      key={color}
                      onClick={() => setSelectedColor(color)}
                      className={`px-4 py-2 rounded-xl font-medium transition-all ${
                        selectedColor === color
                          ? 'bg-[#FFD02F] text-black'
                          : 'bg-white/5 text-white hover:bg-white/10'
                      }`}
                    >
                      {color}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Try On CTA */}
            <div className="pt-4 space-y-3">
              <Link to={`${createPageUrl('TryOn')}?clothId=${product.id}`}>
                <motion.button
                  whileTap={{ scale: 0.98 }}
                  className="w-full py-4 bg-[#FFD02F] text-black rounded-2xl font-bold text-lg flex items-center justify-center gap-3"
                >
                  <Camera size={24} />
                  Try On Virtually
                </motion.button>
              </Link>

              <div className="flex items-center justify-center gap-2 text-white/40 text-sm">
                <Check size={16} className="text-green-500" />
                <span>Virtual try-on enabled</span>
              </div>
            </div>

            {/* AI Size Recommendation */}
            <div className="bg-gradient-to-r from-[#FFD02F]/10 to-transparent border border-[#FFD02F]/20 rounded-2xl p-4">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-[#FFD02F]/20 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Ruler size={20} className="text-[#FFD02F]" />
                </div>
                <div>
                  <p className="text-white font-semibold mb-1">AI Size Recommendation</p>
                  <p className="text-white/50 text-sm">
                    Use our try-on feature to get personalized size recommendations based on your body measurements.
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Related Products */}
        {relatedProducts.filter(p => p.id !== productId).length > 0 && (
          <div className="mt-16">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-white">You May Also Like</h2>
              <Link 
                to={createPageUrl('Marketplace')}
                className="text-[#FFD02F] flex items-center gap-1 text-sm font-medium"
              >
                View All <ChevronRight size={16} />
              </Link>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {relatedProducts.filter(p => p.id !== productId).slice(0, 4).map(item => (
                <Link 
                  key={item.id} 
                  to={`${createPageUrl('ProductDetail')}?id=${item.id}`}
                >
                  <div className="bg-[#141414] rounded-2xl overflow-hidden border border-white/5 hover:border-[#FFD02F]/30 transition-all group">
                    <div className="aspect-square bg-[#1A1A1A] overflow-hidden">
                      {item.image_url ? (
                        <img 
                          src={item.image_url} 
                          alt={item.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <ShoppingBag size={32} className="text-white/10" />
                        </div>
                      )}
                    </div>
                    <div className="p-3">
                      <p className="text-white font-medium truncate text-sm">{item.name}</p>
                      <p className="text-[#FFD02F] font-bold">${item.price?.toFixed(2)}</p>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}