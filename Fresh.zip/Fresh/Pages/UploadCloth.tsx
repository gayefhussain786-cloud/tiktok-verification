import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { motion } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Upload,
  X,
  Image as ImageIcon,
  Check,
  ArrowLeft,
  Plus,
  Trash2,
  Sparkles,
  AlertCircle
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const categories = [
  { value: 'tops', label: 'Tops' },
  { value: 'bottoms', label: 'Bottoms' },
  { value: 'outerwear', label: 'Outerwear' },
  { value: 'dresses', label: 'Dresses' },
  { value: 'activewear', label: 'Activewear' },
  { value: 'accessories', label: 'Accessories' },
];

const sizeOptions = ['XS', 'S', 'M', 'L', 'XL', 'XXL'];

export default function UploadCloth() {
  const queryClient = useQueryClient();
  
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    category: '',
    price: '',
    brand: '',
    sizes: [],
    colors: [],
    image_url: '',
  });
  
  const [imageFile, setImageFile] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [newColor, setNewColor] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const [error, setError] = useState(null);

  // Upload image mutation
  const uploadImageMutation = useMutation({
    mutationFn: async (file) => {
      return base44.integrations.Core.UploadFile({ file });
    }
  });

  // Create clothing item mutation
  const createItemMutation = useMutation({
    mutationFn: (data) => base44.entities.ClothingItem.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['clothingItems']);
      setUploadSuccess(true);
    }
  });

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onload = () => setImagePreview(reader.result);
      reader.readAsDataURL(file);
    }
  };

  const handleSizeToggle = (size) => {
    setFormData(prev => ({
      ...prev,
      sizes: prev.sizes.includes(size)
        ? prev.sizes.filter(s => s !== size)
        : [...prev.sizes, size]
    }));
  };

  const handleAddColor = () => {
    if (newColor.trim() && !formData.colors.includes(newColor.trim())) {
      setFormData(prev => ({
        ...prev,
        colors: [...prev.colors, newColor.trim()]
      }));
      setNewColor('');
    }
  };

  const handleRemoveColor = (color) => {
    setFormData(prev => ({
      ...prev,
      colors: prev.colors.filter(c => c !== color)
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setIsUploading(true);

    try {
      // Validate
      if (!formData.name || !formData.category || !formData.price) {
        throw new Error('Please fill in all required fields');
      }

      let imageUrl = formData.image_url;

      // Upload image if selected
      if (imageFile) {
        const result = await uploadImageMutation.mutateAsync(imageFile);
        imageUrl = result.file_url;
      }

      // Create clothing item
      await createItemMutation.mutateAsync({
        ...formData,
        price: parseFloat(formData.price),
        image_url: imageUrl,
        try_on_enabled: true
      });

    } catch (err) {
      setError(err.message || 'Something went wrong');
    } finally {
      setIsUploading(false);
    }
  };

  if (uploadSuccess) {
    return (
      <div className="min-h-screen bg-[#0A0A0A] flex items-center justify-center p-4">
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="text-center max-w-md"
        >
          <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <Check size={40} className="text-green-500" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-3">Upload Successful!</h2>
          <p className="text-white/50 mb-8">
            Your clothing item has been uploaded and is now available for virtual try-on.
          </p>
          <div className="flex gap-3">
            <Link to={createPageUrl('Marketplace')} className="flex-1">
              <button className="w-full py-3 bg-white/5 text-white rounded-xl font-semibold">
                View in Shop
              </button>
            </Link>
            <button
              onClick={() => {
                setUploadSuccess(false);
                setFormData({
                  name: '',
                  description: '',
                  category: '',
                  price: '',
                  brand: '',
                  sizes: [],
                  colors: [],
                  image_url: '',
                });
                setImageFile(null);
                setImagePreview(null);
              }}
              className="flex-1 py-3 bg-[#FFD02F] text-black rounded-xl font-semibold"
            >
              Upload Another
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0A0A0A]">
      {/* Header */}
      <div className="sticky top-16 md:top-20 z-30 bg-[#0A0A0A]/95 backdrop-blur-xl border-b border-white/5">
        <div className="max-w-3xl mx-auto px-4 md:px-6 py-4 flex items-center justify-between">
          <Link 
            to={createPageUrl('Marketplace')}
            className="inline-flex items-center gap-2 text-white/60 hover:text-white transition-colors"
          >
            <ArrowLeft size={20} />
            <span>Back</span>
          </Link>
          <h1 className="text-white font-bold">Upload Clothing</h1>
          <div className="w-16" />
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 md:px-6 py-8">
        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Image Upload */}
          <div>
            <label className="block text-white font-semibold mb-3">Product Image *</label>
            <div className="relative">
              {imagePreview ? (
                <div className="relative aspect-[4/5] max-w-md mx-auto bg-[#141414] rounded-2xl overflow-hidden">
                  <img 
                    src={imagePreview} 
                    alt="Preview" 
                    className="w-full h-full object-cover"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      setImageFile(null);
                      setImagePreview(null);
                    }}
                    className="absolute top-4 right-4 w-10 h-10 bg-black/50 backdrop-blur-sm rounded-full flex items-center justify-center"
                  >
                    <X size={20} className="text-white" />
                  </button>
                </div>
              ) : (
                <label className="block aspect-[4/5] max-w-md mx-auto bg-[#141414] border-2 border-dashed border-white/10 rounded-2xl cursor-pointer hover:border-[#FFD02F]/30 transition-colors">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageChange}
                    className="hidden"
                  />
                  <div className="h-full flex flex-col items-center justify-center p-8">
                    <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mb-4">
                      <Upload size={28} className="text-white/40" />
                    </div>
                    <p className="text-white font-medium mb-1">Drop your image here</p>
                    <p className="text-white/40 text-sm">or click to browse</p>
                  </div>
                </label>
              )}
            </div>

            {/* AI Background Removal Info */}
            <div className="mt-4 bg-[#FFD02F]/10 border border-[#FFD02F]/20 rounded-xl p-4 flex items-start gap-3 max-w-md mx-auto">
              <Sparkles size={20} className="text-[#FFD02F] flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-[#FFD02F] font-medium text-sm">Auto Background Removal</p>
                <p className="text-white/50 text-xs mt-1">
                  Our AI will automatically remove the background for optimal try-on experience.
                </p>
              </div>
            </div>
          </div>

          {/* Basic Info */}
          <div className="space-y-4">
            <div>
              <label className="block text-white font-semibold mb-2">Product Name *</label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g., Classic Cotton T-Shirt"
                className="bg-[#141414] border-white/10 text-white placeholder-white/30 h-12 rounded-xl"
              />
            </div>

            <div>
              <label className="block text-white font-semibold mb-2">Description</label>
              <Textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Describe your product..."
                className="bg-[#141414] border-white/10 text-white placeholder-white/30 min-h-[100px] rounded-xl"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-white font-semibold mb-2">Category *</label>
                <Select
                  value={formData.category}
                  onValueChange={(value) => setFormData({ ...formData, category: value })}
                >
                  <SelectTrigger className="bg-[#141414] border-white/10 text-white h-12 rounded-xl">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#141414] border-white/10">
                    {categories.map(cat => (
                      <SelectItem key={cat.value} value={cat.value} className="text-white">
                        {cat.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-white font-semibold mb-2">Price ($) *</label>
                <Input
                  type="number"
                  step="0.01"
                  min="0"
                  value={formData.price}
                  onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                  placeholder="0.00"
                  className="bg-[#141414] border-white/10 text-white placeholder-white/30 h-12 rounded-xl"
                />
              </div>
            </div>

            <div>
              <label className="block text-white font-semibold mb-2">Brand (Optional)</label>
              <Input
                value={formData.brand}
                onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
                placeholder="e.g., Nike, Zara"
                className="bg-[#141414] border-white/10 text-white placeholder-white/30 h-12 rounded-xl"
              />
            </div>
          </div>

          {/* Sizes */}
          <div>
            <label className="block text-white font-semibold mb-3">Available Sizes</label>
            <div className="flex flex-wrap gap-2">
              {sizeOptions.map(size => (
                <button
                  key={size}
                  type="button"
                  onClick={() => handleSizeToggle(size)}
                  className={`min-w-[60px] py-3 rounded-xl font-semibold transition-all ${
                    formData.sizes.includes(size)
                      ? 'bg-[#FFD02F] text-black'
                      : 'bg-white/5 text-white/60 hover:text-white hover:bg-white/10'
                  }`}
                >
                  {size}
                </button>
              ))}
            </div>
          </div>

          {/* Colors */}
          <div>
            <label className="block text-white font-semibold mb-3">Available Colors</label>
            <div className="flex gap-2 mb-3">
              <Input
                value={newColor}
                onChange={(e) => setNewColor(e.target.value)}
                placeholder="Add a color (e.g., Black, Navy)"
                className="bg-[#141414] border-white/10 text-white placeholder-white/30 h-12 rounded-xl flex-1"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddColor();
                  }
                }}
              />
              <button
                type="button"
                onClick={handleAddColor}
                className="px-4 bg-white/5 rounded-xl text-white hover:bg-white/10 transition-colors"
              >
                <Plus size={20} />
              </button>
            </div>
            {formData.colors.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {formData.colors.map(color => (
                  <div
                    key={color}
                    className="px-4 py-2 bg-white/5 rounded-xl flex items-center gap-2"
                  >
                    <span className="text-white">{color}</span>
                    <button
                      type="button"
                      onClick={() => handleRemoveColor(color)}
                      className="text-white/40 hover:text-red-400"
                    >
                      <X size={16} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Error */}
          {error && (
            <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-4 flex items-center gap-3">
              <AlertCircle size={20} className="text-red-500 flex-shrink-0" />
              <p className="text-red-400 text-sm">{error}</p>
            </div>
          )}

          {/* Submit */}
          <motion.button
            type="submit"
            disabled={isUploading}
            whileTap={{ scale: 0.98 }}
            className="w-full py-4 bg-[#FFD02F] text-black rounded-2xl font-bold text-lg flex items-center justify-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isUploading ? (
              <>
                <div className="w-5 h-5 border-2 border-black/30 border-t-black rounded-full animate-spin" />
                Uploading...
              </>
            ) : (
              <>
                <Upload size={22} />
                Upload Clothing
              </>
            )}
          </motion.button>
        </form>
      </div>
    </div>
  );
}