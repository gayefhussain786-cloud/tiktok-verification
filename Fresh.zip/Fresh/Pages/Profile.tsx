import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { motion, AnimatePresence } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  User,
  Heart,
  Camera,
  Settings,
  LogOut,
  ChevronRight,
  ShoppingBag,
  Edit2,
  Check,
  X,
  Upload,
  Sparkles
} from 'lucide-react';
import { Input } from '@/components/ui/input';

export default function Profile() {
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState('tryons');
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({ full_name: '' });

  // Fetch current user
  const { data: user, isLoading: userLoading } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  // Fetch try-on sessions
  const { data: tryOnSessions = [] } = useQuery({
    queryKey: ['tryOnSessions'],
    queryFn: () => base44.entities.TryOnSession.list('-created_date', 50),
  });

  // Fetch wishlist
  const { data: wishlist = [] } = useQuery({
    queryKey: ['wishlist'],
    queryFn: () => base44.entities.Wishlist.list('-created_date', 50),
  });

  // Fetch wishlist items details
  const { data: wishlistItems = [] } = useQuery({
    queryKey: ['wishlistItems', wishlist],
    queryFn: async () => {
      if (wishlist.length === 0) return [];
      const itemIds = wishlist.map(w => w.clothing_item_id).filter(Boolean);
      const allItems = await base44.entities.ClothingItem.list('-created_date', 100);
      return allItems.filter(item => itemIds.includes(item.id));
    },
    enabled: wishlist.length > 0
  });

  // Update user profile
  const updateProfileMutation = useMutation({
    mutationFn: (data) => base44.auth.updateMe(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['currentUser']);
      setIsEditing(false);
    }
  });

  // Remove from wishlist
  const removeWishlistMutation = useMutation({
    mutationFn: (id) => base44.entities.Wishlist.delete(id),
    onSuccess: () => queryClient.invalidateQueries(['wishlist'])
  });

  const handleStartEdit = () => {
    setEditData({ full_name: user?.full_name || '' });
    setIsEditing(true);
  };

  const handleSaveProfile = async () => {
    await updateProfileMutation.mutateAsync(editData);
  };

  const handleLogout = () => {
    base44.auth.logout();
  };

  const tabs = [
    { id: 'tryons', label: 'Try-Ons', icon: Camera, count: tryOnSessions.length },
    { id: 'wishlist', label: 'Wishlist', icon: Heart, count: wishlist.length },
  ];

  if (userLoading) {
    return (
      <div className="min-h-screen bg-[#0A0A0A] flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-[#FFD02F] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0A0A0A]">
      {/* Profile Header */}
      <div className="relative bg-gradient-to-b from-[#141414] to-[#0A0A0A] pt-8 pb-12 px-4">
        <div className="max-w-2xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            {/* Avatar */}
            <div className="relative w-24 h-24 mx-auto mb-4">
              <div className="w-full h-full bg-gradient-to-br from-[#FFD02F] to-[#FFA500] rounded-full flex items-center justify-center">
                <span className="text-black text-3xl font-black">
                  {user?.full_name?.charAt(0)?.toUpperCase() || user?.email?.charAt(0)?.toUpperCase() || 'U'}
                </span>
              </div>
              <button className="absolute bottom-0 right-0 w-8 h-8 bg-[#0A0A0A] border-2 border-[#0A0A0A] rounded-full flex items-center justify-center">
                <Camera size={14} className="text-white" />
              </button>
            </div>

            {/* Name */}
            {isEditing ? (
              <div className="max-w-xs mx-auto mb-2">
                <Input
                  value={editData.full_name}
                  onChange={(e) => setEditData({ ...editData, full_name: e.target.value })}
                  placeholder="Your name"
                  className="bg-white/5 border-white/10 text-white text-center h-10 rounded-xl"
                  autoFocus
                />
                <div className="flex gap-2 mt-2 justify-center">
                  <button
                    onClick={() => setIsEditing(false)}
                    className="px-4 py-2 bg-white/5 rounded-xl text-white/60 text-sm"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSaveProfile}
                    className="px-4 py-2 bg-[#FFD02F] rounded-xl text-black text-sm font-semibold"
                  >
                    Save
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-center gap-2 mb-2">
                <h1 className="text-2xl font-bold text-white">
                  {user?.full_name || 'User'}
                </h1>
                <button
                  onClick={handleStartEdit}
                  className="w-8 h-8 bg-white/5 rounded-full flex items-center justify-center"
                >
                  <Edit2 size={14} className="text-white/60" />
                </button>
              </div>
            )}

            <p className="text-white/40">{user?.email}</p>

            {/* Stats */}
            <div className="flex justify-center gap-8 mt-6">
              <div className="text-center">
                <p className="text-2xl font-bold text-white">{tryOnSessions.length}</p>
                <p className="text-white/40 text-sm">Try-Ons</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-white">{wishlist.length}</p>
                <p className="text-white/40 text-sm">Saved</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Tabs */}
      <div className="sticky top-16 md:top-20 z-30 bg-[#0A0A0A] border-b border-white/5">
        <div className="max-w-2xl mx-auto px-4">
          <div className="flex">
            {tabs.map(tab => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex-1 py-4 flex items-center justify-center gap-2 border-b-2 transition-colors ${
                    activeTab === tab.id
                      ? 'border-[#FFD02F] text-[#FFD02F]'
                      : 'border-transparent text-white/40'
                  }`}
                >
                  <Icon size={18} />
                  <span className="font-medium">{tab.label}</span>
                  {tab.count > 0 && (
                    <span className={`px-2 py-0.5 rounded-full text-xs ${
                      activeTab === tab.id ? 'bg-[#FFD02F]/20' : 'bg-white/5'
                    }`}>
                      {tab.count}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-2xl mx-auto px-4 py-6">
        <AnimatePresence mode="wait">
          {activeTab === 'tryons' && (
            <motion.div
              key="tryons"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
            >
              {tryOnSessions.length > 0 ? (
                <div className="grid grid-cols-2 gap-4">
                  {tryOnSessions.map((session, i) => (
                    <motion.div
                      key={session.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.05 }}
                      className="bg-[#141414] rounded-2xl overflow-hidden border border-white/5"
                    >
                      <div className="aspect-square bg-[#1A1A1A]">
                        {session.snapshot_url ? (
                          <img 
                            src={session.snapshot_url} 
                            alt="Try-on" 
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <Camera size={32} className="text-white/20" />
                          </div>
                        )}
                      </div>
                      <div className="p-3">
                        <p className="text-white/40 text-xs">
                          {new Date(session.created_date).toLocaleDateString()}
                        </p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-16">
                  <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Camera size={32} className="text-white/20" />
                  </div>
                  <h3 className="text-white text-lg font-bold mb-2">No try-ons yet</h3>
                  <p className="text-white/40 mb-6">Start trying on clothes virtually!</p>
                  <Link to={createPageUrl('TryOn')}>
                    <button className="px-6 py-3 bg-[#FFD02F] text-black rounded-xl font-semibold">
                      Start Try-On
                    </button>
                  </Link>
                </div>
              )}
            </motion.div>
          )}

          {activeTab === 'wishlist' && (
            <motion.div
              key="wishlist"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
            >
              {wishlistItems.length > 0 ? (
                <div className="space-y-3">
                  {wishlistItems.map((item, i) => (
                    <motion.div
                      key={item.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.05 }}
                      className="bg-[#141414] rounded-2xl p-4 flex items-center gap-4 border border-white/5"
                    >
                      <div className="w-20 h-20 bg-[#1A1A1A] rounded-xl overflow-hidden flex-shrink-0">
                        {item.image_url ? (
                          <img 
                            src={item.image_url} 
                            alt={item.name}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <ShoppingBag size={24} className="text-white/20" />
                          </div>
                        )}
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <p className="text-white font-semibold truncate">{item.name}</p>
                        <p className="text-[#FFD02F] font-bold">${item.price?.toFixed(2)}</p>
                      </div>

                      <div className="flex items-center gap-2">
                        <Link to={`${createPageUrl('TryOn')}?clothId=${item.id}`}>
                          <button className="w-10 h-10 bg-[#FFD02F] rounded-xl flex items-center justify-center">
                            <Camera size={18} className="text-black" />
                          </button>
                        </Link>
                        <button
                          onClick={() => {
                            const wishlistEntry = wishlist.find(w => w.clothing_item_id === item.id);
                            if (wishlistEntry) {
                              removeWishlistMutation.mutate(wishlistEntry.id);
                            }
                          }}
                          className="w-10 h-10 bg-white/5 rounded-xl flex items-center justify-center"
                        >
                          <X size={18} className="text-white/60" />
                        </button>
                      </div>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-16">
                  <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Heart size={32} className="text-white/20" />
                  </div>
                  <h3 className="text-white text-lg font-bold mb-2">No saved items</h3>
                  <p className="text-white/40 mb-6">Save items you love to your wishlist</p>
                  <Link to={createPageUrl('Marketplace')}>
                    <button className="px-6 py-3 bg-[#FFD02F] text-black rounded-xl font-semibold">
                      Browse Shop
                    </button>
                  </Link>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Actions */}
      <div className="max-w-2xl mx-auto px-4 pb-8">
        <div className="bg-[#141414] rounded-2xl border border-white/5 overflow-hidden">
          <Link 
            to={createPageUrl('UploadCloth')}
            className="flex items-center justify-between p-4 hover:bg-white/5 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-[#FFD02F]/10 rounded-xl flex items-center justify-center">
                <Upload size={20} className="text-[#FFD02F]" />
              </div>
              <span className="text-white font-medium">Sell Your Clothes</span>
            </div>
            <ChevronRight size={20} className="text-white/40" />
          </Link>

          <div className="h-px bg-white/5" />

          <Link 
            to={createPageUrl('AIModelGenerator')}
            className="flex items-center justify-between p-4 hover:bg-white/5 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-[#FFD02F]/10 rounded-xl flex items-center justify-center">
                <Sparkles size={20} className="text-[#FFD02F]" />
              </div>
              <span className="text-white font-medium">AI Model Generator</span>
            </div>
            <ChevronRight size={20} className="text-white/40" />
          </Link>

          <div className="h-px bg-white/5" />

          <button
            onClick={handleLogout}
            className="w-full flex items-center justify-between p-4 hover:bg-white/5 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-red-500/10 rounded-xl flex items-center justify-center">
                <LogOut size={20} className="text-red-500" />
              </div>
              <span className="text-red-500 font-medium">Log Out</span>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
}