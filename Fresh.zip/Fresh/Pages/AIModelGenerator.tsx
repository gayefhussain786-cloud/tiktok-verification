import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { useMutation } from '@tanstack/react-query';
import {
  Sparkles,
  Upload,
  Download,
  Image as ImageIcon,
  User,
  RefreshCw,
  X,
  Check,
  AlertCircle
} from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const modelTypes = [
  { value: 'female', label: 'Female Model' },
  { value: 'male', label: 'Male Model' },
  { value: 'neutral', label: 'Neutral' },
];

const poses = [
  { value: 'standing', label: 'Standing Front' },
  { value: 'walking', label: 'Walking' },
  { value: 'sitting', label: 'Sitting' },
  { value: 'dynamic', label: 'Dynamic Pose' },
];

const backgrounds = [
  { value: 'studio', label: 'Studio', color: '#FFFFFF', gradient: 'bg-white' },
  { value: 'street', label: 'Street', color: '#4A4A4A', gradient: 'bg-gradient-to-br from-gray-600 to-gray-800' },
  { value: 'nature', label: 'Nature', color: '#4A7C59', gradient: 'bg-gradient-to-br from-green-600 to-green-900' },
  { value: 'minimal', label: 'Minimal', color: '#9CA3AF', gradient: 'bg-gradient-to-br from-gray-300 to-gray-500' },
];

const complexions = [
  { value: 'fair', label: 'Fair', color: '#FFE5D4' },
  { value: 'light', label: 'Light', color: '#F5D0B5' },
  { value: 'medium', label: 'Medium', color: '#D4A574' },
  { value: 'olive', label: 'Olive', color: '#C4956A' },
  { value: 'tan', label: 'Tan', color: '#A67B5B' },
  { value: 'brown', label: 'Brown', color: '#8B5A3C' },
  { value: 'dark', label: 'Dark', color: '#5C3A21' },
];

export default function AIModelGenerator() {
  const [clothingImage, setClothingImage] = useState(null);
  const [clothingPreview, setClothingPreview] = useState(null);
  const [modelType, setModelType] = useState('female');
  const [pose, setPose] = useState('standing');
  const [background, setBackground] = useState('studio');
  const [complexion, setComplexion] = useState('medium');
  const [generatedImage, setGeneratedImage] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState(null);

  // Upload image
  const uploadMutation = useMutation({
    mutationFn: (file) => base44.integrations.Core.UploadFile({ file })
  });

  // Generate AI model
  const generateMutation = useMutation({
    mutationFn: async ({ imageUrl }) => {
      const prompt = `Create a professional fashion photography image of a ${modelType} model with ${complexion} skin complexion wearing the clothing item shown. 
        Pose: ${pose}, Background: ${background} background. 
        Make it look like a high-end fashion catalog photo with professional lighting.
        The model should be realistic with ${complexion} skin tone and the clothing should fit naturally.`;
      
      return base44.integrations.Core.GenerateImage({ prompt });
    }
  });

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      setClothingImage(file);
      const reader = new FileReader();
      reader.onload = () => setClothingPreview(reader.result);
      reader.readAsDataURL(file);
      setGeneratedImage(null);
      setError(null);
    }
  };

  const handleGenerate = async () => {
    if (!clothingImage) {
      setError('Please upload a clothing image first');
      return;
    }

    setIsGenerating(true);
    setError(null);

    try {
      // Upload the clothing image
      const uploadResult = await uploadMutation.mutateAsync(clothingImage);
      
      // Generate the model image
      const result = await generateMutation.mutateAsync({ 
        imageUrl: uploadResult.file_url 
      });
      
      setGeneratedImage(result.url);
    } catch (err) {
      setError('Failed to generate model. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownload = () => {
    if (!generatedImage) return;
    
    const link = document.createElement('a');
    link.href = generatedImage;
    link.download = `zipright-model-${Date.now()}.png`;
    link.click();
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A]">
      {/* Hero */}
      <div className="relative bg-gradient-to-b from-[#141414] to-[#0A0A0A] py-12 px-4 md:px-6">
        <div className="max-w-5xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#FFD02F]/10 border border-[#FFD02F]/20 rounded-full mb-6">
              <Sparkles size={16} className="text-[#FFD02F]" />
              <span className="text-[#FFD02F] text-sm font-medium">AI-Powered</span>
            </div>
            
            <h1 className="text-3xl md:text-5xl font-black text-white mb-4">
              AI Model <span className="text-[#FFD02F]">Generator</span>
            </h1>
            <p className="text-white/50 text-lg max-w-lg mx-auto">
              Upload your clothing and let AI create professional model photos for your products
            </p>
          </motion.div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 md:px-6 pb-12">
        <div className="grid md:grid-cols-2 gap-8">
          {/* Left - Upload & Settings */}
          <div className="space-y-6">
            {/* Image Upload */}
            <div className="bg-[#141414] rounded-2xl p-6 border border-white/5">
              <h3 className="text-white font-bold mb-4">Upload Clothing</h3>
              
              {clothingPreview ? (
                <div className="relative aspect-square bg-[#1A1A1A] rounded-xl overflow-hidden">
                  <img 
                    src={clothingPreview} 
                    alt="Clothing" 
                    className="w-full h-full object-contain"
                  />
                  <button
                    onClick={() => {
                      setClothingImage(null);
                      setClothingPreview(null);
                      setGeneratedImage(null);
                    }}
                    className="absolute top-3 right-3 w-10 h-10 bg-black/50 backdrop-blur-sm rounded-full flex items-center justify-center"
                  >
                    <X size={20} className="text-white" />
                  </button>
                </div>
              ) : (
                <label className="block aspect-square bg-[#1A1A1A] border-2 border-dashed border-white/10 rounded-xl cursor-pointer hover:border-[#FFD02F]/30 transition-colors">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                  <div className="h-full flex flex-col items-center justify-center">
                    <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mb-4">
                      <Upload size={28} className="text-white/40" />
                    </div>
                    <p className="text-white font-medium mb-1">Upload clothing image</p>
                    <p className="text-white/40 text-sm">PNG, JPG up to 10MB</p>
                  </div>
                </label>
              )}
            </div>

            {/* Settings */}
            <div className="bg-[#141414] rounded-2xl p-6 border border-white/5 space-y-4">
              <h3 className="text-white font-bold">Model Settings</h3>
              
              <div>
                <label className="block text-white/60 text-sm mb-2">Model Type</label>
                <Select value={modelType} onValueChange={setModelType}>
                  <SelectTrigger className="bg-[#1A1A1A] border-white/10 text-white h-12 rounded-xl">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-[#1A1A1A] border-white/10">
                    {modelTypes.map(type => (
                      <SelectItem key={type.value} value={type.value} className="text-white">
                        {type.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-white/60 text-sm mb-2">Pose</label>
                <Select value={pose} onValueChange={setPose}>
                  <SelectTrigger className="bg-[#1A1A1A] border-white/10 text-white h-12 rounded-xl">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-[#1A1A1A] border-white/10">
                    {poses.map(p => (
                      <SelectItem key={p.value} value={p.value} className="text-white">
                        {p.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-white/60 text-sm mb-2">Background</label>
                <div className="grid grid-cols-4 gap-2">
                  {backgrounds.map(bg => (
                    <button
                      key={bg.value}
                      type="button"
                      onClick={() => setBackground(bg.value)}
                      className={`aspect-square rounded-xl overflow-hidden border-2 transition-all ${
                        background === bg.value 
                          ? 'border-[#FFD02F] ring-2 ring-[#FFD02F]/20' 
                          : 'border-white/10 hover:border-white/20'
                      }`}
                    >
                      <div className={`w-full h-full ${bg.gradient} flex items-end justify-center pb-1`}>
                        <span className={`text-[10px] font-medium ${bg.value === 'studio' || bg.value === 'minimal' ? 'text-black/60' : 'text-white/80'}`}>
                          {bg.label}
                        </span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-white/60 text-sm mb-2">Complexion</label>
                <Select value={complexion} onValueChange={setComplexion}>
                  <SelectTrigger className="bg-[#1A1A1A] border-white/10 text-white h-12 rounded-xl">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-[#1A1A1A] border-white/10">
                    {complexions.map(c => (
                      <SelectItem key={c.value} value={c.value} className="text-white">
                        <div className="flex items-center gap-2">
                          <div 
                            className="w-4 h-4 rounded-full border border-white/20" 
                            style={{ backgroundColor: c.color }}
                          />
                          {c.label}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Generate Button */}
            <motion.button
              whileTap={{ scale: 0.98 }}
              onClick={handleGenerate}
              disabled={isGenerating || !clothingImage}
              className="w-full py-4 bg-[#FFD02F] text-black rounded-2xl font-bold text-lg flex items-center justify-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isGenerating ? (
                <>
                  <RefreshCw size={22} className="animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Sparkles size={22} />
                  Generate Model Photo
                </>
              )}
            </motion.button>

            {/* Error */}
            {error && (
              <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-4 flex items-center gap-3">
                <AlertCircle size={20} className="text-red-500 flex-shrink-0" />
                <p className="text-red-400 text-sm">{error}</p>
              </div>
            )}
          </div>

          {/* Right - Generated Result */}
          <div className="bg-[#141414] rounded-2xl p-6 border border-white/5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-white font-bold">Generated Result</h3>
              {generatedImage && (
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  onClick={handleDownload}
                  className="px-4 py-2 bg-[#FFD02F] text-black rounded-xl font-semibold text-sm flex items-center gap-2"
                >
                  <Download size={16} />
                  Download
                </motion.button>
              )}
            </div>

            <div className="aspect-[3/4] bg-[#1A1A1A] rounded-xl overflow-hidden">
              <AnimatePresence mode="wait">
                {isGenerating ? (
                  <motion.div
                    key="loading"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="w-full h-full flex flex-col items-center justify-center"
                  >
                    <div className="relative w-24 h-24">
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
                        className="absolute inset-0 border-4 border-[#FFD02F]/20 border-t-[#FFD02F] rounded-full"
                      />
                      <Sparkles size={32} className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-[#FFD02F]" />
                    </div>
                    <p className="text-white/60 mt-6">Creating your model photo...</p>
                    <p className="text-white/30 text-sm mt-1">This may take 10-15 seconds</p>
                  </motion.div>
                ) : generatedImage ? (
                  <motion.img
                    key="result"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    src={generatedImage}
                    alt="Generated Model"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <motion.div
                    key="empty"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="w-full h-full flex flex-col items-center justify-center"
                  >
                    <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mb-4">
                      <User size={40} className="text-white/20" />
                    </div>
                    <p className="text-white/40 text-center px-8">
                      Upload a clothing image and generate your AI model photo
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Tips */}
            <div className="mt-4 space-y-2">
              <p className="text-white/40 text-xs font-medium uppercase tracking-wider">Tips for best results</p>
              <ul className="text-white/30 text-sm space-y-1">
                <li>• Use high-quality clothing images</li>
                <li>• Plain background works best</li>
                <li>• Ensure the full garment is visible</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}