import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { motion } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import ProductCard from '../components/marketplace/ProductCard';
import FilterBar from '../components/marketplace/FilterBar';
import { ShoppingBag, Plus, Sparkles, Search } from 'lucide-react';

export default function Marketplace() {
  const queryClient = useQueryClient();
  const [category, setCategory] = useState('all');
  const [sortBy, setSortBy] = useState('-created_date');
  const [searchQuery, setSearchQuery] = useState('');
  const [wishlist, setWishlist] = useState(new Set());

  // Fetch clothing items
  const { data: items = [], isLoading } = useQuery({
    queryKey: ['clothingItems', category, sortBy],
    queryFn: async () => {
      if (category === 'all') {
        return base44.entities.ClothingItem.list(sortBy, 100);
      }
      return base44.entities.ClothingItem.filter({ category }, sortBy, 100);
    },
  });

  // Add to wishlist mutation
  const addToWishlistMutation = useMutation({
    mutationFn: (data) => base44.entities.Wishlist.create(data),
    onSuccess: () => queryClient.invalidateQueries(['wishlist'])
  });

  const handleTryOn = (product) => {
    window.location.href = `${createPageUrl('TryOn')}?clothId=${product.id}`;
  };

  const handleLike = async (product) => {
    const newWishlist = new Set(wishlist);
    if (newWishlist.has(product.id)) {
      newWishlist.delete(product.id);
    } else {
      newWishlist.add(product.id);
      await addToWishlistMutation.mutateAsync({ clothing_item_id: product.id });
    }
    setWishlist(newWishlist);
  };

  // Filter items by search
  const filteredItems = items.filter(item => 
    item.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.brand?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-[#0A0A0A]">
      {/* Hero */}
      <div className="relative bg-gradient-to-b from-[#141414] to-[#0A0A0A] py-12 px-4 md:px-6">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <h1 className="text-3xl md:text-5xl font-black text-white mb-4">
              Shop & Try <span className="text-[#FFD02F]">Virtually</span>
            </h1>
            <p className="text-white/50 text-lg max-w-md mx-auto mb-8">
              Browse our collection and try on any item using AR technology
            </p>

            {/* Search Bar */}
            <div className="max-w-xl mx-auto relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-white/40" size={20} />
              <input
                type="text"
                placeholder="Search clothes, brands..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-4 bg-white/5 border border-white/10 rounded-2xl text-white placeholder-white/30 focus:outline-none focus:border-[#FFD02F]/50 transition-colors"
              />
            </div>
          </motion.div>
        </div>
      </div>

      {/* Filter Bar */}
      <FilterBar
        selectedCategory={category}
        onCategoryChange={setCategory}
        sortBy={sortBy}
        onSortChange={setSortBy}
        totalItems={filteredItems.length}
      />

      {/* Products Grid */}
      <div className="max-w-7xl mx-auto px-4 md:px-6 py-8">
        {isLoading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="bg-[#141414] rounded-2xl overflow-hidden animate-pulse">
                <div className="aspect-[3/4] bg-[#1A1A1A]" />
                <div className="p-4 space-y-3">
                  <div className="h-3 bg-[#1A1A1A] rounded w-1/3" />
                  <div className="h-4 bg-[#1A1A1A] rounded w-2/3" />
                  <div className="h-5 bg-[#1A1A1A] rounded w-1/4" />
                </div>
              </div>
            ))}
          </div>
        ) : filteredItems.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
            {filteredItems.map((item, i) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
              >
                <ProductCard
                  product={item}
                  onTryOn={handleTryOn}
                  onLike={handleLike}
                  isLiked={wishlist.has(item.id)}
                />
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <div className="w-24 h-24 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-6">
              <ShoppingBag size={40} className="text-white/20" />
            </div>
            <h3 className="text-white text-xl font-bold mb-2">No items found</h3>
            <p className="text-white/40 mb-8">
              {searchQuery ? 'Try a different search term' : 'Be the first to add items'}
            </p>
            <Link to={createPageUrl('UploadCloth')}>
              <motion.button
                whileTap={{ scale: 0.95 }}
                className="px-6 py-3 bg-[#FFD02F] text-black rounded-xl font-bold inline-flex items-center gap-2"
              >
                <Plus size={20} />
                Upload Clothing
              </motion.button>
            </Link>
          </div>
        )}
      </div>

      {/* CTA Banner */}
      <div className="max-w-7xl mx-auto px-4 md:px-6 pb-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-gradient-to-r from-[#FFD02F]/10 to-[#FFD02F]/5 border border-[#FFD02F]/20 rounded-3xl p-8 md:p-12 flex flex-col md:flex-row items-center justify-between gap-6"
        >
          <div className="text-center md:text-left">
            <div className="flex items-center gap-2 justify-center md:justify-start mb-3">
              <Sparkles className="text-[#FFD02F]" size={20} />
              <span className="text-[#FFD02F] font-semibold">For Sellers</span>
            </div>
            <h3 className="text-white text-2xl font-bold mb-2">
              Start Selling on ZipRIGHT
            </h3>
            <p className="text-white/50">
              Upload your clothing and reach thousands of customers with virtual try-on
            </p>
          </div>
          
          <Link to={createPageUrl('UploadCloth')}>
            <motion.button
              whileTap={{ scale: 0.95 }}
              className="px-8 py-4 bg-[#FFD02F] text-black rounded-2xl font-bold whitespace-nowrap flex items-center gap-2"
            >
              <Plus size={20} />
              Start Selling
            </motion.button>
          </Link>
        </motion.div>
      </div>
    </div>
  );
}