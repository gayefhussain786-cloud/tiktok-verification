import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import CameraView from '../components/tryon/CameraView';
import ClothSelector from '../components/tryon/ClothSelector';
import ControlPanel from '../components/tryon/ControlPanel';
import { 
  X, 
  Download, 
  Share2, 
  Check,
  AlertCircle,
  Camera
} from 'lucide-react';

export default function TryOn() {
  const cameraRef = useRef(null);
  const queryClient = useQueryClient();
  
  const [selectedCloth, setSelectedCloth] = useState(null);
  const [clothSelectorOpen, setClothSelectorOpen] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [isLiked, setIsLiked] = useState(false);
  const [snapshot, setSnapshot] = useState(null);
  const [notification, setNotification] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [poseData, setPoseData] = useState(null);

  // Fetch clothing items
  const { data: clothes = [] } = useQuery({
    queryKey: ['clothingItems'],
    queryFn: () => base44.entities.ClothingItem.filter({ try_on_enabled: true }, '-created_date', 50),
  });

  // Save try-on session
  const saveTryOnMutation = useMutation({
    mutationFn: (data) => base44.entities.TryOnSession.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['tryOnSessions']);
      showNotification('Saved to your try-on history!', 'success');
    }
  });

  // Add to wishlist
  const addToWishlistMutation = useMutation({
    mutationFn: (data) => base44.entities.Wishlist.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['wishlist']);
      showNotification('Added to wishlist!', 'success');
    }
  });

  // Initialize with first cloth
  useEffect(() => {
    if (clothes.length > 0 && !selectedCloth) {
      setSelectedCloth(clothes[0]);
    }
  }, [clothes]);

  const showNotification = (message, type = 'info') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 3000);
  };

  const handleCapture = async () => {
    if (!cameraRef.current) return;
    
    setIsProcessing(true);
    try {
      const dataUrl = cameraRef.current.captureSnapshot();
      if (dataUrl) {
        setSnapshot(dataUrl);
        
        // Save try-on session
        if (selectedCloth) {
          await saveTryOnMutation.mutateAsync({
            clothing_item_id: selectedCloth.id,
            snapshot_url: dataUrl,
            liked: isLiked
          });
        }
      }
    } catch (error) {
      showNotification('Failed to capture snapshot', 'error');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDownloadSnapshot = () => {
    if (!snapshot) return;
    
    const link = document.createElement('a');
    link.download = `zipright-tryon-${Date.now()}.png`;
    link.href = snapshot;
    link.click();
    
    showNotification('Snapshot downloaded!', 'success');
  };

  const handleShare = async () => {
    if (navigator.share && snapshot) {
      try {
        const blob = await (await fetch(snapshot)).blob();
        const file = new File([blob], 'zipright-tryon.png', { type: 'image/png' });
        
        await navigator.share({
          title: 'Check out my virtual try-on!',
          text: `I tried on ${selectedCloth?.name || 'this outfit'} on ZipRIGHT`,
          files: [file]
        });
      } catch (error) {
        showNotification('Sharing cancelled', 'info');
      }
    } else {
      // Fallback - copy link
      showNotification('Share feature not available on this device', 'info');
    }
  };

  const handleLike = async () => {
    setIsLiked(!isLiked);
    
    if (!isLiked && selectedCloth) {
      await addToWishlistMutation.mutateAsync({
        clothing_item_id: selectedCloth.id
      });
    }
  };

  const currentIndex = clothes.findIndex(c => c.id === selectedCloth?.id);
  
  const handlePrevCloth = () => {
    if (clothes.length === 0) return;
    const newIndex = currentIndex > 0 ? currentIndex - 1 : clothes.length - 1;
    setSelectedCloth(clothes[newIndex]);
  };

  const handleNextCloth = () => {
    if (clothes.length === 0) return;
    const newIndex = currentIndex < clothes.length - 1 ? currentIndex + 1 : 0;
    setSelectedCloth(clothes[newIndex]);
  };

  const handlePoseDetected = (pose) => {
    setPoseData(pose);
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A]">
      {/* Main Camera View */}
      <div className="relative h-[calc(100vh-80px)] md:h-[calc(100vh-80px)] md:max-w-5xl md:mx-auto md:p-4">
        <div className="h-full md:rounded-3xl overflow-hidden">
          <CameraView
            ref={cameraRef}
            selectedCloth={selectedCloth}
            onPoseDetected={handlePoseDetected}
            isProcessing={isProcessing}
          />
        </div>

        {/* Selected Cloth Info - Desktop */}
        {selectedCloth && (
          <div className="hidden md:flex absolute top-8 left-1/2 -translate-x-1/2 items-center gap-3 px-5 py-3 bg-[#141414]/95 backdrop-blur-xl rounded-2xl border border-white/10">
            <div className="w-12 h-12 bg-[#1A1A1A] rounded-xl overflow-hidden">
              {selectedCloth.image_url && (
                <img 
                  src={selectedCloth.image_url} 
                  alt={selectedCloth.name}
                  className="w-full h-full object-cover"
                />
              )}
            </div>
            <div>
              <p className="text-white font-semibold">{selectedCloth.name}</p>
              <p className="text-[#FFD02F] font-bold">${selectedCloth.price?.toFixed(2)}</p>
            </div>
          </div>
        )}

        {/* Pose Stats - Desktop */}
        {poseData && (
          <div className="hidden md:block absolute bottom-8 right-8">
            <div className="bg-[#141414]/95 backdrop-blur-xl rounded-2xl border border-white/10 p-4 space-y-2">
              <p className="text-white/40 text-xs font-medium uppercase tracking-wider">Detection Stats</p>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                <span className="text-white text-sm">Body Detected</span>
              </div>
              <div className="text-white/40 text-xs">
                Confidence: {Math.round(poseData.confidence * 100)}%
              </div>
            </div>
          </div>
        )}

        {/* Control Panel */}
        <ControlPanel
          onCapture={handleCapture}
          onOpenClothSelector={() => setClothSelectorOpen(true)}
          onPrevCloth={handlePrevCloth}
          onNextCloth={handleNextCloth}
          onShare={handleShare}
          onLike={handleLike}
          voiceEnabled={voiceEnabled}
          onToggleVoice={() => setVoiceEnabled(!voiceEnabled)}
          isLiked={isLiked}
          selectedCloth={selectedCloth}
        />

        {/* Cloth Selector */}
        <AnimatePresence>
          {clothSelectorOpen && (
            <ClothSelector
              clothes={clothes}
              selectedCloth={selectedCloth}
              onSelect={setSelectedCloth}
              isOpen={clothSelectorOpen}
              onClose={() => setClothSelectorOpen(false)}
            />
          )}
        </AnimatePresence>
      </div>

      {/* Snapshot Preview Modal */}
      <AnimatePresence>
        {snapshot && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-lg"
            >
              {/* Close Button */}
              <button
                onClick={() => setSnapshot(null)}
                className="absolute -top-12 right-0 w-10 h-10 bg-white/10 rounded-full flex items-center justify-center"
              >
                <X size={20} className="text-white" />
              </button>

              {/* Image */}
              <div className="bg-[#141414] rounded-3xl overflow-hidden">
                <img 
                  src={snapshot} 
                  alt="Snapshot" 
                  className="w-full"
                />
                
                {/* Actions */}
                <div className="p-4 flex gap-3">
                  <motion.button
                    whileTap={{ scale: 0.95 }}
                    onClick={handleDownloadSnapshot}
                    className="flex-1 py-3 bg-[#FFD02F] text-black rounded-xl font-bold flex items-center justify-center gap-2"
                  >
                    <Download size={20} />
                    Download
                  </motion.button>
                  
                  <motion.button
                    whileTap={{ scale: 0.95 }}
                    onClick={handleShare}
                    className="flex-1 py-3 bg-white/5 text-white rounded-xl font-bold flex items-center justify-center gap-2"
                  >
                    <Share2 size={20} />
                    Share
                  </motion.button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Notification Toast */}
      <AnimatePresence>
        {notification && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-40 md:bottom-8 left-4 right-4 md:left-1/2 md:-translate-x-1/2 md:w-auto z-50"
          >
            <div className={`px-5 py-3 rounded-2xl flex items-center gap-3 ${
              notification.type === 'success' 
                ? 'bg-green-500/20 border border-green-500/30' 
                : notification.type === 'error'
                ? 'bg-red-500/20 border border-red-500/30'
                : 'bg-[#FFD02F]/20 border border-[#FFD02F]/30'
            }`}>
              {notification.type === 'success' && <Check size={20} className="text-green-500" />}
              {notification.type === 'error' && <AlertCircle size={20} className="text-red-500" />}
              <span className="text-white text-sm font-medium">{notification.message}</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}