import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from './utils';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Home, 
  Camera, 
  ShoppingBag, 
  User, 
  Sparkles,
  Menu,
  X
} from 'lucide-react';

export default function Layout({ children, currentPageName }) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  // Hide layout for splash screen
  if (currentPageName === 'Splash') {
    return children;
  }

  const navItems = [
    { name: 'Home', icon: Home, page: 'Home' },
    { name: 'Try On', icon: Camera, page: 'TryOn' },
    { name: 'Shop', icon: ShoppingBag, page: 'Marketplace' },
    { name: 'AI Model', icon: Sparkles, page: 'AIModelGenerator' },
    { name: 'Profile', icon: User, page: 'Profile' },
  ];

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-white">
      <style>{`
        :root {
          --brand-yellow: #FFD02F;
          --brand-black: #0A0A0A;
          --brand-dark: #141414;
          --brand-gray: #1A1A1A;
        }
        
        * {
          -webkit-tap-highlight-color: transparent;
        }
        
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        
        @keyframes shimmer {
          0% { background-position: -200% 0; }
          100% { background-position: 200% 0; }
        }
        
        .shimmer {
          background: linear-gradient(90deg, #1A1A1A 25%, #2A2A2A 50%, #1A1A1A 75%);
          background-size: 200% 100%;
          animation: shimmer 1.5s infinite;
        }
      `}</style>

      {/* Desktop Header */}
      <header className="hidden md:block fixed top-0 left-0 right-0 z-50 bg-[#0A0A0A]/95 backdrop-blur-xl border-b border-white/5">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <Link to={createPageUrl('Home')} className="flex items-center gap-2">
            <div className="w-10 h-10 bg-[#FFD02F] rounded-xl flex items-center justify-center">
              <span className="text-black font-black text-lg">Z</span>
            </div>
            <span className="font-black text-2xl tracking-tight">
              Zip<span className="text-[#FFD02F]">RIGHT</span>
            </span>
          </Link>

          <nav className="flex items-center gap-1">
            {navItems.map((item) => (
              <Link
                key={item.page}
                to={createPageUrl(item.page)}
                className={`px-5 py-2.5 rounded-full text-sm font-medium transition-all duration-300 ${
                  currentPageName === item.page
                    ? 'bg-[#FFD02F] text-black'
                    : 'text-white/70 hover:text-white hover:bg-white/5'
                }`}
              >
                {item.name}
              </Link>
            ))}
          </nav>

          <Link
            to={createPageUrl('UploadCloth')}
            className="px-6 py-2.5 bg-white text-black rounded-full text-sm font-semibold hover:bg-white/90 transition-all"
          >
            Sell Clothes
          </Link>
        </div>
      </header>

      {/* Mobile Header */}
      <header className="md:hidden fixed top-0 left-0 right-0 z-50 bg-[#0A0A0A]/95 backdrop-blur-xl border-b border-white/5">
        <div className="px-4 h-16 flex items-center justify-between">
          <Link to={createPageUrl('Home')} className="flex items-center gap-2">
            <div className="w-8 h-8 bg-[#FFD02F] rounded-lg flex items-center justify-center">
              <span className="text-black font-black text-sm">Z</span>
            </div>
            <span className="font-black text-xl tracking-tight">
              Zip<span className="text-[#FFD02F]">RIGHT</span>
            </span>
          </Link>

          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="w-10 h-10 flex items-center justify-center rounded-xl bg-white/5"
          >
            {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        {/* Mobile Menu Dropdown */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="bg-[#0A0A0A] border-b border-white/5 overflow-hidden"
            >
              <div className="p-4 space-y-2">
                <Link
                  to={createPageUrl('UploadCloth')}
                  onClick={() => setMobileMenuOpen(false)}
                  className="block w-full px-4 py-3 bg-[#FFD02F] text-black rounded-xl text-center font-semibold"
                >
                  Sell Your Clothes
                </Link>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Main Content */}
      <main className="pt-16 md:pt-20 pb-24 md:pb-8">
        {children}
      </main>

      {/* Mobile Bottom Navigation */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-[#0A0A0A]/95 backdrop-blur-xl border-t border-white/10">
        <div className="flex items-center justify-around h-20 px-2 pb-safe">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPageName === item.page;
            
            return (
              <Link
                key={item.page}
                to={createPageUrl(item.page)}
                className="flex flex-col items-center gap-1 py-2 px-3 rounded-2xl transition-all"
              >
                <motion.div
                  whileTap={{ scale: 0.9 }}
                  className={`w-12 h-12 flex items-center justify-center rounded-2xl transition-all ${
                    isActive 
                      ? 'bg-[#FFD02F]' 
                      : 'bg-transparent'
                  }`}
                >
                  <Icon 
                    size={22} 
                    className={isActive ? 'text-black' : 'text-white/60'} 
                  />
                </motion.div>
                <span className={`text-[10px] font-medium ${
                  isActive ? 'text-[#FFD02F]' : 'text-white/40'
                }`}>
                  {item.name}
                </span>
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}