import React, { useRef, useEffect, useState, forwardRef, useImperativeHandle } from 'react';
import { motion } from 'framer-motion';
import { Camera, CameraOff, RotateCcw } from 'lucide-react';

const CameraView = forwardRef(({ onPoseDetected, selectedCloth, isProcessing }, ref) => {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const overlayCanvasRef = useRef(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [facingMode, setFacingMode] = useState('user');
  const [poseData, setPoseData] = useState(null);
  const animationFrameRef = useRef(null);
  const poseDetectorRef = useRef(null);

  useImperativeHandle(ref, () => ({
    captureSnapshot: () => {
      if (!canvasRef.current || !overlayCanvasRef.current) return null;
      
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      canvas.width = canvasRef.current.width;
      canvas.height = canvasRef.current.height;
      
      // Draw video frame
      ctx.drawImage(canvasRef.current, 0, 0);
      // Draw overlay (cloth)
      ctx.drawImage(overlayCanvasRef.current, 0, 0);
      
      return canvas.toDataURL('image/png');
    },
    getVideoElement: () => videoRef.current
  }));

  const startCamera = async (mode = facingMode) => {
    try {
      if (videoRef.current?.srcObject) {
        videoRef.current.srcObject.getTracks().forEach(track => track.stop());
      }

      const constraints = {
        video: {
          facingMode: mode,
          width: { ideal: 1280 },
          height: { ideal: 720 }
        }
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.onloadedmetadata = () => {
          videoRef.current.play();
          setCameraActive(true);
          startPoseDetection();
        };
      }
    } catch (err) {
      console.error('Camera error:', err);
      setCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (videoRef.current?.srcObject) {
      videoRef.current.srcObject.getTracks().forEach(track => track.stop());
    }
    setCameraActive(false);
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
    }
  };

  const switchCamera = () => {
    const newMode = facingMode === 'user' ? 'environment' : 'user';
    setFacingMode(newMode);
    startCamera(newMode);
  };

  // Simplified pose detection simulation (MediaPipe would be integrated here)
  const startPoseDetection = () => {
    const detectPose = () => {
      if (!videoRef.current || !canvasRef.current || !cameraActive) return;

      const video = videoRef.current;
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 480;

      // Mirror the video for selfie mode
      ctx.save();
      if (facingMode === 'user') {
        ctx.scale(-1, 1);
        ctx.translate(-canvas.width, 0);
      }
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      ctx.restore();

      // Simulated pose landmarks (in production, use MediaPipe)
      const simulatedPose = {
        landmarks: {
          leftShoulder: { x: canvas.width * 0.35, y: canvas.height * 0.3 },
          rightShoulder: { x: canvas.width * 0.65, y: canvas.height * 0.3 },
          leftHip: { x: canvas.width * 0.38, y: canvas.height * 0.6 },
          rightHip: { x: canvas.width * 0.62, y: canvas.height * 0.6 },
          nose: { x: canvas.width * 0.5, y: canvas.height * 0.15 }
        },
        confidence: 0.9
      };

      setPoseData(simulatedPose);
      if (onPoseDetected) {
        onPoseDetected(simulatedPose);
      }

      // Draw cloth overlay if selected
      if (selectedCloth && overlayCanvasRef.current) {
        drawClothOverlay(simulatedPose);
      }

      animationFrameRef.current = requestAnimationFrame(detectPose);
    };

    detectPose();
  };

  const drawClothOverlay = (pose) => {
    const overlayCanvas = overlayCanvasRef.current;
    const ctx = overlayCanvas.getContext('2d');
    const canvas = canvasRef.current;
    
    overlayCanvas.width = canvas.width;
    overlayCanvas.height = canvas.height;
    ctx.clearRect(0, 0, overlayCanvas.width, overlayCanvas.height);

    if (!selectedCloth?.image_url || !pose?.landmarks) return;

    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const { leftShoulder, rightShoulder, leftHip, rightHip } = pose.landmarks;
      
      // Calculate cloth dimensions and position
      const shoulderWidth = Math.abs(rightShoulder.x - leftShoulder.x);
      const torsoHeight = Math.abs(leftHip.y - leftShoulder.y);
      
      const clothWidth = shoulderWidth * 1.8;
      const clothHeight = torsoHeight * 1.4;
      const clothX = (leftShoulder.x + rightShoulder.x) / 2 - clothWidth / 2;
      const clothY = leftShoulder.y - clothHeight * 0.15;

      // Apply depth-based scaling (simulated)
      const depthScale = 1 + (pose.landmarks.nose.y / canvas.height) * 0.2;
      
      ctx.globalAlpha = 0.85;
      ctx.drawImage(
        img,
        clothX - (clothWidth * depthScale - clothWidth) / 2,
        clothY,
        clothWidth * depthScale,
        clothHeight * depthScale
      );
    };
    img.src = selectedCloth.image_url;
  };

  useEffect(() => {
    startCamera();
    return () => {
      stopCamera();
    };
  }, []);

  return (
    <div className="relative w-full h-full bg-[#0A0A0A] rounded-2xl overflow-hidden">
      {/* Hidden video element */}
      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted
        className="hidden"
      />

      {/* Main canvas with video feed */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full object-contain"
      />

      {/* Overlay canvas for cloth */}
      <canvas
        ref={overlayCanvasRef}
        className="absolute inset-0 w-full h-full object-contain pointer-events-none"
      />

      {/* Camera Status Overlay */}
      {!cameraActive && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#141414]">
          <div className="text-center">
            <motion.div
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="w-24 h-24 bg-[#FFD02F]/10 rounded-full flex items-center justify-center mx-auto mb-4"
            >
              <CameraOff size={40} className="text-[#FFD02F]" />
            </motion.div>
            <p className="text-white/60 mb-4">Camera access required</p>
            <button
              onClick={() => startCamera()}
              className="px-6 py-3 bg-[#FFD02F] text-black rounded-xl font-semibold"
            >
              Enable Camera
            </button>
          </div>
        </div>
      )}

      {/* Processing Indicator */}
      {isProcessing && (
        <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
          <div className="text-center">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
              className="w-12 h-12 border-4 border-[#FFD02F] border-t-transparent rounded-full mx-auto mb-3"
            />
            <p className="text-white text-sm">Processing...</p>
          </div>
        </div>
      )}

      {/* Corner Guides */}
      <div className="absolute top-4 left-4 w-12 h-12 border-t-2 border-l-2 border-[#FFD02F]/50 rounded-tl-xl" />
      <div className="absolute top-4 right-4 w-12 h-12 border-t-2 border-r-2 border-[#FFD02F]/50 rounded-tr-xl" />
      <div className="absolute bottom-4 left-4 w-12 h-12 border-b-2 border-l-2 border-[#FFD02F]/50 rounded-bl-xl" />
      <div className="absolute bottom-4 right-4 w-12 h-12 border-b-2 border-r-2 border-[#FFD02F]/50 rounded-br-xl" />

      {/* Camera Switch Button */}
      <button
        onClick={switchCamera}
        className="absolute top-4 right-4 w-10 h-10 bg-black/50 backdrop-blur-sm rounded-full flex items-center justify-center border border-white/10"
      >
        <RotateCcw size={18} className="text-white" />
      </button>

      {/* Status Badge */}
      {cameraActive && (
        <div className="absolute top-4 left-4 flex items-center gap-2 px-3 py-1.5 bg-black/50 backdrop-blur-sm rounded-full border border-white/10">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
          <span className="text-white text-xs font-medium">Live</span>
        </div>
      )}

      {/* Pose Confidence */}
      {poseData && (
        <div className="absolute bottom-4 left-4 px-3 py-1.5 bg-black/50 backdrop-blur-sm rounded-full border border-white/10">
          <span className="text-white/60 text-xs">
            Body Tracking: <span className="text-green-400 font-medium">{Math.round(poseData.confidence * 100)}%</span>
          </span>
        </div>
      )}
    </div>
  );
});

CameraView.displayName = 'CameraView';

export default CameraView;