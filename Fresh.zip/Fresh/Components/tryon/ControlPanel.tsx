import React from 'react';
import { motion } from 'framer-motion';
import { 
  Camera, 
  Shirt, 
  Mic, 
  MicOff, 
  Share2, 
  Heart, 
  ChevronLeft, 
  ChevronRight,
  Download,
  Sparkles
} from 'lucide-react';

export default function ControlPanel({
  onCapture,
  onOpenClothSelector,
  onPrevCloth,
  onNextCloth,
  onShare,
  onLike,
  voiceEnabled,
  onToggleVoice,
  isLiked,
  selectedCloth
}) {
  return (
    <>
      {/* Mobile Bottom Controls */}
      <div className="md:hidden fixed bottom-20 left-0 right-0 z-40 px-4">
        <div className="bg-[#141414]/95 backdrop-blur-xl rounded-3xl border border-white/10 p-4">
          {/* Main Actions Row */}
          <div className="flex items-center justify-between gap-2">
            {/* Prev Cloth */}
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={onPrevCloth}
              className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center"
            >
              <ChevronLeft size={24} className="text-white" />
            </motion.button>

            {/* Select Cloth */}
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={onOpenClothSelector}
              className="flex-1 h-12 bg-white/5 rounded-2xl flex items-center justify-center gap-2"
            >
              <Shirt size={20} className="text-[#FFD02F]" />
              <span className="text-white text-sm font-medium">
                {selectedCloth?.name || 'Select Cloth'}
              </span>
            </motion.button>

            {/* Capture Button */}
            <motion.button
              whileTap={{ scale: 0.85 }}
              onClick={onCapture}
              className="w-16 h-16 bg-[#FFD02F] rounded-full flex items-center justify-center shadow-lg shadow-[#FFD02F]/20"
            >
              <Camera size={28} className="text-black" />
            </motion.button>

            {/* Voice Command */}
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={onToggleVoice}
              className={`w-12 h-12 rounded-2xl flex items-center justify-center ${
                voiceEnabled ? 'bg-[#FFD02F]' : 'bg-white/5'
              }`}
            >
              {voiceEnabled ? (
                <Mic size={20} className="text-black" />
              ) : (
                <MicOff size={20} className="text-white/60" />
              )}
            </motion.button>

            {/* Next Cloth */}
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={onNextCloth}
              className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center"
            >
              <ChevronRight size={24} className="text-white" />
            </motion.button>
          </div>

          {/* Secondary Actions */}
          <div className="flex items-center justify-center gap-4 mt-4">
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={onLike}
              className={`px-4 py-2 rounded-xl flex items-center gap-2 ${
                isLiked ? 'bg-red-500/20' : 'bg-white/5'
              }`}
            >
              <Heart 
                size={18} 
                className={isLiked ? 'text-red-500 fill-red-500' : 'text-white/60'} 
              />
              <span className={`text-sm ${isLiked ? 'text-red-500' : 'text-white/60'}`}>
                Save
              </span>
            </motion.button>

            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={onShare}
              className="px-4 py-2 bg-white/5 rounded-xl flex items-center gap-2"
            >
              <Share2 size={18} className="text-white/60" />
              <span className="text-white/60 text-sm">Share</span>
            </motion.button>
          </div>
        </div>
      </div>

      {/* Desktop Side Controls */}
      <div className="hidden md:block absolute left-4 top-1/2 -translate-y-1/2 z-40">
        <div className="bg-[#141414]/95 backdrop-blur-xl rounded-2xl border border-white/10 p-3 space-y-3">
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={onOpenClothSelector}
            className="w-12 h-12 bg-white/5 hover:bg-white/10 rounded-xl flex items-center justify-center transition-colors group"
            title="Select Clothing"
          >
            <Shirt size={22} className="text-[#FFD02F]" />
          </motion.button>

          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={onPrevCloth}
            className="w-12 h-12 bg-white/5 hover:bg-white/10 rounded-xl flex items-center justify-center transition-colors"
            title="Previous"
          >
            <ChevronLeft size={22} className="text-white" />
          </motion.button>

          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={onNextCloth}
            className="w-12 h-12 bg-white/5 hover:bg-white/10 rounded-xl flex items-center justify-center transition-colors"
            title="Next"
          >
            <ChevronRight size={22} className="text-white" />
          </motion.button>

          <div className="h-px bg-white/10" />

          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={onCapture}
            className="w-12 h-12 bg-[#FFD02F] hover:bg-[#FFD02F]/90 rounded-xl flex items-center justify-center transition-colors shadow-lg shadow-[#FFD02F]/20"
            title="Capture"
          >
            <Camera size={22} className="text-black" />
          </motion.button>

          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={onToggleVoice}
            className={`w-12 h-12 rounded-xl flex items-center justify-center transition-colors ${
              voiceEnabled ? 'bg-[#FFD02F]' : 'bg-white/5 hover:bg-white/10'
            }`}
            title="Voice Commands"
          >
            {voiceEnabled ? (
              <Mic size={22} className="text-black" />
            ) : (
              <MicOff size={22} className="text-white/60" />
            )}
          </motion.button>

          <div className="h-px bg-white/10" />

          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={onLike}
            className={`w-12 h-12 rounded-xl flex items-center justify-center transition-colors ${
              isLiked ? 'bg-red-500/20' : 'bg-white/5 hover:bg-white/10'
            }`}
            title="Save to Wishlist"
          >
            <Heart 
              size={22} 
              className={isLiked ? 'text-red-500 fill-red-500' : 'text-white/60'} 
            />
          </motion.button>

          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={onShare}
            className="w-12 h-12 bg-white/5 hover:bg-white/10 rounded-xl flex items-center justify-center transition-colors"
            title="Share"
          >
            <Share2 size={22} className="text-white/60" />
          </motion.button>
        </div>
      </div>
    </>
  );
}