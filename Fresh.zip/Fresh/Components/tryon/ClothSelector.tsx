import React from 'react';
import { motion } from 'framer-motion';
import { ShoppingBag, Check, ChevronLeft, ChevronRight, X } from 'lucide-react';

export default function ClothSelector({ 
  clothes, 
  selectedCloth, 
  onSelect, 
  isOpen, 
  onClose 
}) {
  const [activeIndex, setActiveIndex] = React.useState(0);

  React.useEffect(() => {
    if (selectedCloth) {
      const idx = clothes.findIndex(c => c.id === selectedCloth.id);
      if (idx >= 0) setActiveIndex(idx);
    }
  }, [selectedCloth, clothes]);

  const handlePrev = () => {
    const newIndex = activeIndex > 0 ? activeIndex - 1 : clothes.length - 1;
    setActiveIndex(newIndex);
    onSelect(clothes[newIndex]);
  };

  const handleNext = () => {
    const newIndex = activeIndex < clothes.length - 1 ? activeIndex + 1 : 0;
    setActiveIndex(newIndex);
    onSelect(clothes[newIndex]);
  };

  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ y: '100%' }}
      animate={{ y: 0 }}
      exit={{ y: '100%' }}
      transition={{ type: 'spring', damping: 25, stiffness: 300 }}
      className="fixed bottom-0 left-0 right-0 z-50 md:absolute md:bottom-auto md:top-4 md:right-4 md:left-auto md:w-80"
    >
      <div className="bg-[#141414] border-t border-white/10 md:border md:rounded-2xl p-4 pb-8 md:pb-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-white font-bold">Select Clothing</h3>
          <button
            onClick={onClose}
            className="w-8 h-8 bg-white/5 rounded-full flex items-center justify-center"
          >
            <X size={16} className="text-white/60" />
          </button>
        </div>

        {/* Current Selection */}
        {clothes.length > 0 && (
          <div className="mb-4">
            <div className="relative aspect-square max-w-[200px] mx-auto bg-[#1A1A1A] rounded-xl overflow-hidden">
              {clothes[activeIndex]?.image_url ? (
                <img
                  src={clothes[activeIndex].image_url}
                  alt={clothes[activeIndex].name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <ShoppingBag size={40} className="text-white/20" />
                </div>
              )}

              {/* Navigation Arrows */}
              <button
                onClick={handlePrev}
                className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 bg-black/50 backdrop-blur-sm rounded-full flex items-center justify-center"
              >
                <ChevronLeft size={18} className="text-white" />
              </button>
              <button
                onClick={handleNext}
                className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 bg-black/50 backdrop-blur-sm rounded-full flex items-center justify-center"
              >
                <ChevronRight size={18} className="text-white" />
              </button>
            </div>

            <div className="text-center mt-3">
              <p className="text-white font-semibold">{clothes[activeIndex]?.name}</p>
              <p className="text-[#FFD02F] font-bold">${clothes[activeIndex]?.price?.toFixed(2)}</p>
            </div>
          </div>
        )}

        {/* Thumbnails */}
        <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-2">
          {clothes.map((cloth, idx) => (
            <motion.button
              key={cloth.id}
              whileTap={{ scale: 0.95 }}
              onClick={() => {
                setActiveIndex(idx);
                onSelect(cloth);
              }}
              className={`relative flex-shrink-0 w-16 h-16 rounded-xl overflow-hidden border-2 transition-all ${
                activeIndex === idx
                  ? 'border-[#FFD02F] ring-2 ring-[#FFD02F]/20'
                  : 'border-white/10'
              }`}
            >
              {cloth.image_url ? (
                <img
                  src={cloth.image_url}
                  alt={cloth.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full bg-[#1A1A1A] flex items-center justify-center">
                  <ShoppingBag size={20} className="text-white/20" />
                </div>
              )}
              {activeIndex === idx && (
                <div className="absolute inset-0 bg-[#FFD02F]/20 flex items-center justify-center">
                  <Check size={20} className="text-[#FFD02F]" />
                </div>
              )}
            </motion.button>
          ))}
        </div>

        {/* Empty State */}
        {clothes.length === 0 && (
          <div className="text-center py-8">
            <ShoppingBag size={40} className="text-white/20 mx-auto mb-3" />
            <p className="text-white/40">No clothes available</p>
          </div>
        )}

        {/* Apply Button */}
        <motion.button
          whileTap={{ scale: 0.98 }}
          onClick={onClose}
          className="w-full mt-4 py-3 bg-[#FFD02F] text-black rounded-xl font-bold"
        >
          Apply to Try-On
        </motion.button>
      </div>
    </motion.div>
  );
}