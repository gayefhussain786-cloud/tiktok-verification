import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Filter, X, ChevronDown, Check } from 'lucide-react';

const categories = [
  { value: 'all', label: 'All Categories' },
  { value: 'tops', label: 'Tops' },
  { value: 'bottoms', label: 'Bottoms' },
  { value: 'outerwear', label: 'Outerwear' },
  { value: 'dresses', label: 'Dresses' },
  { value: 'activewear', label: 'Activewear' },
  { value: 'accessories', label: 'Accessories' },
];

const sortOptions = [
  { value: '-created_date', label: 'Newest' },
  { value: 'price', label: 'Price: Low to High' },
  { value: '-price', label: 'Price: High to Low' },
  { value: 'name', label: 'Name: A-Z' },
];

export default function FilterBar({ 
  selectedCategory, 
  onCategoryChange, 
  sortBy, 
  onSortChange,
  totalItems 
}) {
  const [showFilters, setShowFilters] = useState(false);
  const [showSort, setShowSort] = useState(false);

  return (
    <div className="sticky top-16 md:top-20 z-30 bg-[#0A0A0A]/95 backdrop-blur-xl border-b border-white/5 py-4">
      <div className="max-w-7xl mx-auto px-4 md:px-6">
        {/* Mobile */}
        <div className="md:hidden flex items-center gap-3">
          <button
            onClick={() => setShowFilters(!showFilters)}
            className={`flex-1 py-3 rounded-xl flex items-center justify-center gap-2 transition-colors ${
              selectedCategory !== 'all' 
                ? 'bg-[#FFD02F] text-black' 
                : 'bg-white/5 text-white'
            }`}
          >
            <Filter size={18} />
            <span className="font-medium">
              {categories.find(c => c.value === selectedCategory)?.label || 'Filter'}
            </span>
          </button>

          <button
            onClick={() => setShowSort(!showSort)}
            className="flex-1 py-3 bg-white/5 rounded-xl flex items-center justify-center gap-2 text-white"
          >
            <span className="font-medium">
              {sortOptions.find(s => s.value === sortBy)?.label || 'Sort'}
            </span>
            <ChevronDown size={18} />
          </button>
        </div>

        {/* Mobile Filter Panel */}
        <AnimatePresence>
          {showFilters && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="md:hidden overflow-hidden"
            >
              <div className="pt-4 grid grid-cols-2 gap-2">
                {categories.map(cat => (
                  <button
                    key={cat.value}
                    onClick={() => {
                      onCategoryChange(cat.value);
                      setShowFilters(false);
                    }}
                    className={`py-3 rounded-xl text-sm font-medium transition-colors ${
                      selectedCategory === cat.value
                        ? 'bg-[#FFD02F] text-black'
                        : 'bg-white/5 text-white/60'
                    }`}
                  >
                    {cat.label}
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Mobile Sort Panel */}
        <AnimatePresence>
          {showSort && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="md:hidden overflow-hidden"
            >
              <div className="pt-4 space-y-2">
                {sortOptions.map(opt => (
                  <button
                    key={opt.value}
                    onClick={() => {
                      onSortChange(opt.value);
                      setShowSort(false);
                    }}
                    className={`w-full py-3 rounded-xl text-sm font-medium flex items-center justify-between px-4 transition-colors ${
                      sortBy === opt.value
                        ? 'bg-[#FFD02F] text-black'
                        : 'bg-white/5 text-white/60'
                    }`}
                  >
                    {opt.label}
                    {sortBy === opt.value && <Check size={18} />}
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Desktop */}
        <div className="hidden md:flex items-center justify-between">
          <div className="flex items-center gap-2">
            {categories.map(cat => (
              <button
                key={cat.value}
                onClick={() => onCategoryChange(cat.value)}
                className={`px-5 py-2.5 rounded-full text-sm font-medium transition-all ${
                  selectedCategory === cat.value
                    ? 'bg-[#FFD02F] text-black'
                    : 'bg-white/5 text-white/60 hover:text-white hover:bg-white/10'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-4">
            <span className="text-white/40 text-sm">{totalItems} items</span>
            
            <div className="relative">
              <button
                onClick={() => setShowSort(!showSort)}
                className="px-5 py-2.5 bg-white/5 rounded-full text-sm font-medium text-white flex items-center gap-2 hover:bg-white/10 transition-colors"
              >
                {sortOptions.find(s => s.value === sortBy)?.label || 'Sort'}
                <ChevronDown size={16} />
              </button>

              <AnimatePresence>
                {showSort && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="absolute right-0 top-full mt-2 w-48 bg-[#141414] rounded-xl border border-white/10 overflow-hidden shadow-xl"
                  >
                    {sortOptions.map(opt => (
                      <button
                        key={opt.value}
                        onClick={() => {
                          onSortChange(opt.value);
                          setShowSort(false);
                        }}
                        className={`w-full px-4 py-3 text-left text-sm font-medium flex items-center justify-between hover:bg-white/5 transition-colors ${
                          sortBy === opt.value ? 'text-[#FFD02F]' : 'text-white/60'
                        }`}
                      >
                        {opt.label}
                        {sortBy === opt.value && <Check size={16} />}
                      </button>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}