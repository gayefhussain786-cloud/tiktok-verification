import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../../utils';
import { motion } from 'framer-motion';
import { ShoppingBag, Heart, Camera, Star } from 'lucide-react';

export default function ProductCard({ product, onTryOn, onLike, isLiked }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="group"
    >
      <div className="bg-[#141414] rounded-2xl overflow-hidden border border-white/5 hover:border-[#FFD02F]/30 transition-all duration-300">
        {/* Image */}
        <div className="relative aspect-[3/4] bg-[#1A1A1A] overflow-hidden">
          {product.image_url ? (
            <img 
              src={product.image_url} 
              alt={product.name}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <ShoppingBag size={48} className="text-white/10" />
            </div>
          )}

          {/* Overlay on hover */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

          {/* Quick Actions */}
          <div className="absolute bottom-0 left-0 right-0 p-3 flex gap-2 opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 transition-all duration-300">
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={(e) => {
                e.preventDefault();
                onTryOn && onTryOn(product);
              }}
              className="flex-1 py-2.5 bg-[#FFD02F] text-black rounded-xl font-semibold text-sm flex items-center justify-center gap-2"
            >
              <Camera size={16} />
              Try On
            </motion.button>
            
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={(e) => {
                e.preventDefault();
                onLike && onLike(product);
              }}
              className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                isLiked ? 'bg-red-500' : 'bg-white/10 backdrop-blur-sm'
              }`}
            >
              <Heart 
                size={18} 
                className={isLiked ? 'text-white fill-white' : 'text-white'} 
              />
            </motion.button>
          </div>

          {/* Featured Badge */}
          {product.is_featured && (
            <div className="absolute top-3 left-3 px-2.5 py-1 bg-[#FFD02F] rounded-lg flex items-center gap-1">
              <Star size={12} className="text-black fill-black" />
              <span className="text-black text-xs font-bold">Featured</span>
            </div>
          )}
        </div>

        {/* Info */}
        <Link to={`${createPageUrl('ProductDetail')}?id=${product.id}`}>
          <div className="p-4">
            <p className="text-white/40 text-xs font-medium uppercase tracking-wider mb-1">
              {product.brand || product.category?.replace(/_/g, ' ')}
            </p>
            <h3 className="text-white font-semibold mb-2 truncate">
              {product.name}
            </h3>
            <div className="flex items-center justify-between">
              <p className="text-[#FFD02F] font-bold text-lg">
                ${product.price?.toFixed(2)}
              </p>
              {product.sizes?.length > 0 && (
                <p className="text-white/30 text-xs">
                  {product.sizes.join(' · ')}
                </p>
              )}
            </div>
          </div>
        </Link>
      </div>
    </motion.div>
  );
}